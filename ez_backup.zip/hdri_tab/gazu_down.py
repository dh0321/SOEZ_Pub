import gazu

gazu.client.set_host("http://192.168.3.117/api")
gazu.log_in("admin@netflixacademy.com", "netflixacademy")

# 프로젝트, 어셋, 태스크, 프리뷰 찾기 위한 변수 지정 및 함수들
project_name = "SOEZ_TEST_2"
asset_name = 'exr_test'
output_type_name = 'MOV'
output_type_short_name = 'MOV'
status_name = 'Todo'
user_comment = '0801_maya_ui_success => main_ui_ver3_4.Ui_MainWindow.textEdit_leave_a_comment.text()'
project = gazu.project.get_project_by_name(project_name)
asset = gazu.asset.get_asset_by_name(project, asset_name)
task_type = None
task_types = gazu.task.all_task_types_for_project(project)
for task_type in task_types:
    if task_type['name'] == 'Shading' and task_type['for_entity'] == asset['type']:
        task_type = task_type
        break

# print 들로 딕셔너리의 값들을 확인함
print(task_type)
print(asset)
task = gazu.task.get_task_by_name(asset, task_type)
print(task)
set_pre_id = asset['preview_file_id']
print('t', asset)

# 다운로드 함수에 필요한 프리뷰 파일의 아이디를 확인하기 위한 변수
gp = gazu.files.get_preview_file(asset['preview_file_id'])
print(gp)

# 다운로드 함수에 필요한 프리뷰 파일패스를 확인하기 위한 변수
dpp = '/home/rapa/비디오/' + gp['original_name'] + '.' + gp['extension']
print(dpp)

# 실질적으로 다운로드 해주는 함수
dp = gazu.files.download_preview_file(preview_file=asset['preview_file_id'],file_path=dpp)
print('suc', dp)