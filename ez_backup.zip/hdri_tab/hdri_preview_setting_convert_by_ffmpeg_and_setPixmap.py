# -*- coding: utf-8 -*-
import gazu

from PySide2.QtWidgets import QApplication, QMainWindow
from PySide2.QtGui import QImage, QPixmap
from main_ui_ver3_7 import Ui_MainWindow as main_ui

import os.path
import os

class MainWindow(QMainWindow, main_ui):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.setupUi(self)
        gazu.client.set_host('http://192.168.3.117/api')
        gazu.log_in('admin@netflixacademy.com', 'netflixacademy')


        self.listWidget_change_hdri_img.itemSelectionChanged.connect(self.show_jpg_image)

        self.show_jpg_image('/home/rapa/PycharmProjects/pythonProject/exr/test_jpg/studio_small_09_4k.jpg')
        # self.extract_thumbnail_from_exr() ## add hdri 할 때 실행되도록


    def extract_thumbnail_from_exr(self):
        input_dir = "/home/rapa/PycharmProjects/pythonProject/exr"
        input_file_name = 'studio_small_09_4k'
        input_file_extension = 'exr'

        input_file_path = f'{input_dir}/{input_file_name}.{input_file_extension}'
        print(input_file_path)


        output_dir = '/home/rapa/PycharmProjects/pythonProject/exr/test_jpg'
        output_name = "studio_small_09_4k"
        output_vide_format = 'jpg'
        output_file_path = f'{output_dir}/{output_name}.{output_vide_format}'
        print(output_file_path)
        jpeg_pixel = '320'

        command_input = f'ffmpeg -i {input_file_path} -vf "scale={jpeg_pixel}:-1" -vframes 1 {output_file_path}'
        print(command_input)
        self.run_ffmpeg(command_input)

    def run_ffmpeg(self, commands):
        if os.system(commands) == 0:
            pass
            # print("ffmpeg Script Ran Successfully")
            # self.upload_msg_label.setText('Upload Success!!')
            # self.upload_msg_label.setStyleSheet('color: #ed8d20;')
        # else:
            # print("There was an error running your ffmpeg script")
            # self.upload_msg_label.setText('Error')
            # self.upload_msg_label.setStyleSheet('color: red;')

    def show_jpg_image(self, image):
        pixmap = QPixmap(os.path.join(os.path.dirname(__file__), image))
        # pixmap = QPixmap('/home/rapa/PycharmProjects/pythonProject/exr/', image))
        # print(pixmap) >>> <PySide2.QtGui.QPixmap(null) at 0x7fe45de5a188>
        # self.label_preview_hdri_img_import.setPixmap(pixmap)
        self.label_preview_hdri_img_add.setPixmap(pixmap)

app = QApplication()

window = MainWindow()
window.show()

app.exec_()