# -*- coding: utf-8 -*-
from ui_v3.main_ui_ver3_5 import Ui_MainWindow
from PySide2.QtWidgets import QApplication, QMainWindow, QFileDialog
from PySide2.QtGui import QPixmap, Qt


import gazu
import os
import shutil


class MainWindow(QMainWindow, Ui_MainWindow):

    def __init__(self):
        super(MainWindow, self).__init__()

        # gazu
        gazu.client.set_host("http://192.168.3.117/api")
        gazu.log_in("admin@netflixacademy.com", "netflixacademy")

        # project
        self.project = gazu.project.get_project_by_name('HDRI Library')

        # all assets
        self.all_assets = gazu.asset.all_assets_for_project(self.project["id"])

        # UI
        self.setupUi(self)
        self.setWindowTitle("EZ PUB")

        # hdri_list_import
        self.add_item_hdri_list()  # 생성
        self.listWidget_change_hdri_img.itemClicked.connect(self.hdri_list_clicked)

        # hdri_pub
        # self.pushButton_hdri_path
        self.pushButton_hdri_path.clicked.connect(self.pushButton_hdri_path_clicked)
        self.pushButton_publish_hdri_img.clicked.connect(self.pushButton_publish_hdri_img_clicked)

        # log out
        self.pushButton_logout.clicked.connect(self.logout_btn_clicked)



    def add_item_hdri_list(self):
        self.listWidget_change_hdri_img.clear()  # 초기화
        self.all_assets = gazu.asset.all_assets_for_project(self.project["id"])
        for self.asset in self.all_assets:
            self.listWidget_change_hdri_img.addItem(self.asset['name'])

    def hdri_list_clicked(self):
        selected_item = self.listWidget_change_hdri_img.currentItem().text()
        print(selected_item)
        preview_file_id = None
        for self.asset in self.all_assets:
            if selected_item == self.asset["name"]:
                preview_file_id = self.asset['preview_file_id']
                break
        print(self.asset)

        print(preview_file_id)

        # 다운로드 함수에 필요한 프리뷰 파일의 아이디를 확인하기 위한 변수
        self.gp = gazu.files.get_preview_file(preview_file_id)
        print(self.gp)

        task_type = None
        task_types = gazu.task.all_task_types_for_project(self.project)
        for task_type in task_types:
            if task_type['name'] == 'Shading' and task_type['for_entity'] == self.asset['type']:
                task_type = task_type
                break
        task = gazu.task.get_task_by_name(self.asset, task_type)

        working_file_info = gazu.files.get_working_files_for_task(task)
        print("working_file_info", working_file_info)
        self.path = working_file_info[-1]["path"]
        print("path", self.path)
        if os.path.exists(self.path) is False:
            os.makedirs(self.path)
        else:
            pass

        # 다운로드 함수에 필요한 프리뷰 파일패스를 확인하기 위한 변수
        self.dpp = self.path + "/" + self.gp['original_name'] + '.' + self.gp['extension']
        print(self.dpp)

        # 실질적으로 다운로드 해주는 함수
        dp = gazu.files.download_preview_file(preview_file=preview_file_id, file_path=self.dpp)
        print('suc', dp)

        self.extract_thumbnail_from_exr(self.dpp, self.path, self.gp['original_name'])

        # label을 변경
        # self.change_label_preview_hdri_img_import()

        self.change_label_preview_hdri_img_import(self.output_file_path)


    def extract_thumbnail_from_exr(self, input_file, output_path, output_file_name):
        input_file_path = input_file
        print(input_file_path)

        self.output_dir = "%s/preview_jpg" % (output_path)
        output_name = output_file_name
        output_format = 'jpg'
        self.output_file_path = '%s/%s.%s' % (self.output_dir, output_name, output_format)
        print(self.output_file_path)
        jpeg_pixel = '320'

        command_input = 'ffmpeg -i %s -vf "scale=%s:-1" -vframes 1 %s' % (input_file_path, jpeg_pixel, self.output_file_path)
        print(command_input)
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        if not os.path.exists(self.output_file_path):
            self.run_ffmpeg(command_input)

    def run_ffmpeg(self, commands):
        if os.system(commands) == 0:
            pass
            # print("ffmpeg Script Ran Successfully")
            # self.upload_msg_label.setText('Upload Success!!')
            # self.upload_msg_label.setStyleSheet('color: #ed8d20;')
        # else:
            # print("There was an error running your ffmpeg script")
            # self.upload_msg_label.setText('Error')
            # self.upload_msg_label.setStyleSheet('color: red;')


    def change_label_preview_hdri_img_import(self, image):
        hdri_img_to_view = QPixmap(os.path.join(os.path.dirname(__file__), image))
        scaled_hdri_img_to_view = hdri_img_to_view.scaled(self.label_preview_hdri_img_import.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.label_preview_hdri_img_import.setPixmap(scaled_hdri_img_to_view)

        print("change")

    def pushButton_hdri_path_clicked(self):
        options = QFileDialog.Options()
        self.file_name, _ = QFileDialog.getOpenFileName(self, "Open Image", "",
                                                   ".exr(*.exr);; All Files (*)", options=options)
        if self.file_name:
            print("Selected file path:", self.file_name)

        self.lineEdit_hdri_path.setText(self.file_name)

        dir_path = os.path.dirname(self.file_name)

        name = os.path.basename(self.file_name)

        self.extract_thumbnail_from_exr(self.file_name, dir_path, name)

        self.change_label_preview_hdri_img_add(self.output_file_path)


    def change_label_preview_hdri_img_add(self, image):
        hdri_img_to_view = QPixmap(os.path.join(os.path.dirname(__file__), image))
        scaled_hdri_img_to_view = hdri_img_to_view.scaled(self.label_preview_hdri_img_import.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.label_preview_hdri_img_add.setPixmap(scaled_hdri_img_to_view)

        print("change")

    def pushButton_publish_hdri_img_clicked(self):
        # asset_type
        asset_type_id = None
        all_asset_types = gazu.asset.all_asset_types_for_project(self.project)
        if all_asset_types == [] or all_asset_types != "Environment":
            gazu.asset.new_asset_type("Environment")
            asset_type = gazu.asset.get_asset_type_by_name("Environment")
            asset_type_id = asset_type['id']

        for asset_type in all_asset_types:
            if "Environment" == asset_type["name"]:
                asset_type_id = asset_type['id']


        if self.file_name:
            # 파일 경로에서 파일 이름만 추출합니다.
            self.file_name_only = os.path.basename(self.file_name)

        gazu.asset.new_asset(project=self.project, asset_type=asset_type_id, name=self.file_name_only)

        asset = gazu.asset.get_asset_by_name(self.project, self.file_name_only)
        user_comment = "happy~ happy~ happy~ lala~ lala~ la~ la~ "

        # task_type
        all_task_types = gazu.task.all_task_types_for_project(self.project)
        print(all_task_types)
        print(asset['type'])
        for task_type in all_task_types:
            if task_type['name'] == 'Concept' and task_type['for_entity'] == asset['type']:
                print(task_type['for_entity'])
                print(task_type['name'])
                upload_task_type = task_type
                break

        gazu.task.new_task(asset, upload_task_type)
        task = gazu.task.get_task_by_name(asset, upload_task_type)

        kitsu_upload_path = "%s" % self.file_name

        comment = gazu.task.add_comment(task, '3d24de8b-b327-4c95-a469-392637497234', comment=user_comment)
        preview = gazu.task.add_preview(task, comment, preview_file_path=kitsu_upload_path)
        gazu.task.set_main_preview(preview['id'])

        self.add_item_hdri_list()
        self.lineEdit_hdri_path.clear()
        self.label_preview_hdri_img_add.clear()

        working_file = gazu.files.new_working_file(task)
        print(working_file)

        self.delete_jpg_file(self.output_dir)

    def delete_jpg_file(self, jpg_dir):
        print("이미지 지우기:")
        shutil.rmtree(jpg_dir)

    def logout_btn_clicked(self):
        self.login.log_out()
        self.window().close()
        self.lg.show()

    def update_filetree(self, mountpoint, root):
        """
        파일 트리를 업데이트하는 매서드

        Args:
            mountpoint(str/path): 폴더 트리를 생성할 위치의 전체 경로
            root(str/folder name): 폴더 트리를 생성할 mountpoint의 자식 폴더 이름
        """
        gazu.client.set_host("http://192.168.3.117/api")
        gazu.log_in("admin@netflixacademy.com", "netflixacademy")

        tree = {
            "working": {
                "mountpoint": mountpoint,
                "root": root,
                "folder_path": {
                    "shot": "<Project>/shots/<Sequence>/<Shot>/<TaskType>/working",
                    "asset": "<Project>/assets/<AssetType>/<Asset>/<TaskType>/working",
                    "style": "lowercase"
                },
                "file_name": {
                    "shot": "<Project>_<Sequence>_<Shot>_<TaskType>_<Revision>",
                    "asset": "<Project>_<AssetType>_<Asset>_<TaskType>_<Revision>",
                    "style": "lowercase"
                }
            },
            "output": {
                "mountpoint": mountpoint,
                "root": root,
                "folder_path": {
                    "shot": "<Project>/shots/<Sequence>/<Shot>/<TaskType>/output/<OutputType>/v<Revision>",
                    "asset": "<Project>/assets/<AssetType>/<Asset>/<TaskType>/output/<OutputType>/v<Revision>",
                    "style": "lowercase"
                },
                "file_name": {
                    "shot": "<Project>_<Sequence>_<Shot>_<OutputType>_v<Revision>",
                    "asset": "<Project>_<AssetType>_<Asset>_<OutputType>_v<Revision>",
                    "style": "lowercase"
                }
            }
        }
        project = gazu.project.get_project_by_name('HDRI Library')
        gazu.files.update_project_file_tree(project, tree)


if __name__ == "__main__":
    app = QApplication()
    window = MainWindow()
    window.show()
    app.exec_()

