import gazu

gazu.client.set_host("http://192.168.3.117/api")
gazu.log_in("admin@netflixacademy.com", "netflixacademy")
#필요 정보들 가져오는데 사용한 메소드들

get_pj = gazu.project.all_open_projects()
get_all_pj = gazu.project.all_projects()
get_single_pj = gazu.project.get_project_by_name('SOEZ_TEST_2')
pj_asset = gazu.asset.all_assets_for_project(get_single_pj['id'])
#for 문으로 프로젝트의 이름들을 조회한다
for p in range(len(get_pj)):
    print(get_all_pj[p]['name'])

#어셋 조회 확인
print(get_single_pj)
print(pj_asset[0]['name'])
#for 문으로 지정된 프로젝트의 어셋 이름들을 조회한다
for a in range(len(pj_asset)):
    print(pj_asset[a]['name'])