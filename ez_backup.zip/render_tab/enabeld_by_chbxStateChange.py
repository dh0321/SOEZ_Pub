# -*- coding: utf-8 -*-
from PySide2.QtWidgets import QApplication, QMainWindow
import gazu

from main_ui_ver3_6 import Ui_MainWindow as main_ui


class MainWindow(QMainWindow, main_ui):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.setupUi(self)
        gazu.client.set_host('http://192.168.3.117/api')
        gazu.log_in('admin@netflixacademy.com', 'netflixacademy')

        self.checkBox_change_setting.stateChanged.connect(self.chbxStateChange)

    # def current_enabled(self):
    #     print('current_enabled')

    def chbxStateChange(self):
        print("isChecked", self.checkBox_change_setting.isChecked)
        if self.checkBox_change_setting.isChecked():
            print('setEnabled  True')
            self.lineEdit_mesh_start_frame.setEnabled(True)
            self.lineEdit_mesh_end_frame.setEnabled(True)
            self.lineEdit_img_format.setEnabled(True)
            self.lineEdit_vid_format.setEnabled(True)
            self.lineEdit_img_name.setEnabled(True)
            self.lineEdit_img_path.setEnabled(True)
            self.lineEdit_vid_name.setEnabled(True)
            self.lineEdit_vid_path.setEnabled(True)
        else:
            print('setEnabled  False')
            self.lineEdit_mesh_start_frame.setDisabled(True)
            self.lineEdit_mesh_end_frame.setDisabled(True)
            self.lineEdit_img_format.setDisabled(True)
            self.lineEdit_vid_format.setDisabled(True)
            self.lineEdit_img_name.setDisabled(True)
            self.lineEdit_img_path.setDisabled(True)
            self.lineEdit_vid_name.setDisabled(True)
            self.lineEdit_vid_path.setDisabled(True)



app = QApplication()

window = MainWindow()
window.show()

app.exec_()