# -*- coding: utf-8 -*-

import maya.cmds as cmds
import os
import sys

first_selected_objects = cmds.ls(selection=True)

class part2():
    def __init__(self):

        self.object_start_frame = None
        self.object_end_frame = None
        self.dome_start_frame = None
        self.dome_end_frame = None

    def import_camera(self):
        asset_path = "/home/rapa/MayaAssets/default_assets/turntable_camera.mb"

        if os.path.exists(asset_path):
            cmds.file(asset_path, i=True)
        else:
            print('wrong path')

    # import hdri
    def create_skydome_light(self, image_path):
        skydome_light = cmds.shadingNode('aiSkyDomeLight', asLight=True)
        file_node = cmds.shadingNode('file', asTexture=True)
        cmds.setAttr(file_node + ".fileTextureName", image_path, type="string")
        cmds.connectAttr(file_node + ".outColor", skydome_light + ".color")
        cmds.rename(skydome_light, "awesome_skydome")
        return skydome_light

    # change hdri path
    def change_skydome_image_path(self, image_path):
        file_node = cmds.listConnections("awesome_skydome" + ".color", type="file")

        if file_node:
            cmds.setAttr(file_node[0] + ".fileTextureName", image_path, type="string")
            print("Skydome image path changed to: " + image_path)
        else:
            print("No file node connected to the skydome light.")

    # change camera view
    def switch_camera(self):
        cmds.lookThru("turntable_camera")

    # fit to frame
    def fit_selection_in_frame(self):

        if cmds.ls(selection=True):
            cmds.viewFit(first_selected_objects, fitFactor=1, animate=True)
        else:
            print("Please select the objects")

    # draw anim graph
    def rotate_objects(self, sf, ef):
        print(sf, ef)
        self.object_start_frame = sf
        self.object_end_frame = ef

        cmds.select(first_selected_objects, visible=True)
        cmds.setKeyframe(first_selected_objects, value=0, attribute='rotateY', time=self.object_start_frame)
        cmds.setKeyframe(first_selected_objects, value=360, attribute='rotateY', time=self.object_end_frame)
        cmds.keyTangent(first_selected_objects, inTangentType='linear', outTangentType='linear', time=(self.object_start_frame, self.object_end_frame))

    def rotate_dome(self, sf, ef):
        self.object_start_frame = sf
        self.object_end_frame = ef
        self.dome_start_frame = self.object_end_frame + 1
        self.dome_end_frame = self.object_end_frame - self.object_start_frame + self.dome_start_frame

        cmds.select("awesome_skydome", visible=True)
        cmds.setKeyframe("awesome_skydome", value=0, attribute='rotateY', time=self.dome_start_frame)
        cmds.setKeyframe("awesome_skydome", value=360, attribute='rotateY', time=self.dome_end_frame)
        cmds.keyTangent("awesome_skydome", inTangentType='linear', outTangentType='linear', time=(self.dome_start_frame, self.dome_end_frame))
