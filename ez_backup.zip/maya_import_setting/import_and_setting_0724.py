import maya.cmds as cmds
import os

first_selected_objects = cmds.ls(selection=True)

class part2:

    def import_camera(self):
        asset_path = "/home/rapa/MayaAssets/default_assets/turntable_camera.mb"

        if os.path.exists(asset_path):
            cmds.file(asset_path, i=True)
        else:
            print('wrong path')

    # import hdri
    def create_skydome_light(self, image_path):
        skydome_light = cmds.shadingNode('aiSkyDomeLight', asLight=True)
        file_node = cmds.shadingNode('file', asTexture=True)
        cmds.setAttr(file_node + ".fileTextureName", image_path, type="string")
        cmds.connectAttr(file_node + ".outColor", skydome_light + ".color")
        cmds.rename(skydome_light, "awesome_skydome")
        return skydome_light

    # change hdri path
    def change_skydome_image_path(self, image_path):
        file_node = cmds.listConnections("awesome_skydome" + ".color", type="file")

        if file_node:
            cmds.setAttr(file_node[0] + ".fileTextureName", image_path, type="string")
            print("Skydome image path changed to: " + image_path)
        else:
            print("No file node connected to the skydome light.")


    # change camera view
    def switch_camera(self):
        cmds.lookThru("turntable_camera")

    # fit to frame
    def fit_selection_in_frame(self):
        cmds.select(first_selected_objects)
        cmds.viewFit(fitFactor=1, animate=True)

        if cmds.ls(selection=True):
            cmds.viewFit(fitFactor=1, animate=True)
        else:
            print("Please select the objects")

    # draw anime graph
    def rotate_objects(self, start_key_value, end_key_value, start_frame, end_frame):
        cmds.GraphEditor()
        cmds.select(first_selected_objects, visible=True)

        cmds.setKeyframe(value=start_key_value, attribute='rotateY', time=start_frame)
        cmds.setKeyframe(value=end_key_value, attribute='rotateY', time=end_frame)
        cmds.keyTangent(first_selected_objects, inTangentType='linear', outTangentType='linear', time=(start_frame, end_frame))


    # hdri는 렌더 결과로만 회전 확인 가능
    def rotate_dome(self, start_key_value, end_key_value, start_frame, end_frame):
        cmds.GraphEditor()
        cmds.select("awesome_skydome", visible=True)

        cmds.setKeyframe(value=start_key_value, attribute='rotateY', time=start_frame)
        cmds.setKeyframe(value=end_key_value, attribute='rotateY', time=end_frame)
        cmds.keyTangent("awesome_skydome", inTangentType='linear', outTangentType='linear', time=(start_frame, end_frame))


# use -----------------------------------------------------
p2 = part2()

p2.import_camera()

image_path = "/home/rapa/MayaAssets/asset_hdri/little_paris_under_tower_4k.exr"
p2.create_skydome_light(image_path)

new_image_path = "/home/rapa/MayaAssets/asset_hdri/studio_small_09_4k.exr"
p2.change_skydome_image_path(new_image_path)

p2.switch_camera()

p2.fit_selection_in_frame()

start_key_value = 0
end_key_value = 360  # user input
object_start_frame = 0
object_end_frame = 24  # user input
p2.rotate_objects(start_key_value, end_key_value, object_start_frame, object_end_frame)

start_key_value = 0
end_key_value = 360  # user input
input_start_frame = 0
input_end_frame = 24  # user input
dome_start_frame = object_end_frame + input_start_frame
dome_end_frame = object_end_frame + input_end_frame
p2.rotate_dome(start_key_value, end_key_value, dome_start_frame, dome_end_frame)

