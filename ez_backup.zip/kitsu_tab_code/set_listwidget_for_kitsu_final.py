# -*- coding: utf-8 -*-
from PySide2.QtWidgets import QApplication, QMainWindow
import gazu

from main_ui_ver3_6 import Ui_MainWindow as main_ui


class MainWindow(QMainWindow, main_ui):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.setupUi(self)
        gazu.client.set_host('http://192.168.3.117/api')
        gazu.log_in('admin@netflixacademy.com', 'netflixacademy')

        self.all_project_infos = gazu.project.all_projects()

        # 프로젝트와 에셋의 이름 전부를 리스트에 각각 담고, 리스트위젯에 세팅한다.
        self.set_projects_list()
        # self.set_assets_list_by_project()

        # 기본값을 첫번째 프로젝트로 선택하고, 항목(프로젝트)를 바꾸면 현재 선택된 텍스트를 출력하는 메서드로 연결한다.
        # self.listWidget_vid_project.setCurrentItem(self.listWidget_vid_project.item(0))
        try:
            self.listWidget_vid_project.itemSelectionChanged.connect(self.set_assets_list_by_project) # == itemClicked
        except AttributeError:
            print('select project')

    def set_projects_list(self):
        print("-------set_projects_list------")
        self.listWidget_vid_project.clear()
        self.project_list = []
        for project_infos in self.all_project_infos:
            # print(project_infos['name'])
            self.project_list.append(project_infos['name'])
        self.listWidget_vid_project.addItems(self.project_list)
        # print("project_list : ", self.project_list)

    def set_assets_list_by_project(self):
        print("-------set_assets_list_by_project------")
        self.listWidget_vid_asset.clear()
        self.current_project_text = self.listWidget_vid_project.currentItem().text()
        print("current_project_text : ", self.current_project_text)
        for project_infos in self.all_project_infos:
            if project_infos["name"] == self.current_project_text:
                assets_info = gazu.asset.all_assets_for_project(project_infos["id"])
                for asset in assets_info:
                    self.listWidget_vid_asset.addItem(asset["name"])


app = QApplication()

window = MainWindow()
window.show()

app.exec_()