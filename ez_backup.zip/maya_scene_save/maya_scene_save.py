import maya.cmds as cmds
import os


def save_scene_file(path, name, representation):
    full_path = path + name + '.' + representation
    maya_path = os.path.dirname(full_path)
    if not os.path.exists(maya_path):
        os.makedirs(maya_path)
    cmds.file(rename=full_path)
    if representation == 'mb':
        cmds.file(save=True, type='mayaBinary', force=True)
    else:
        cmds.file(save=True, type='mayaAscii', force=True)


save_scene_file('/home/rapa/maya/projects/default/images/', 'tmp', 'ma')


###################################################
# path 파라미터에 들어가는 부분의 경우,
# /home/rapa/maya/projects/default/images/ => 경로
# tmp => 씬파일 이름으로 저장됨
###################################################
