# -*- coding: utf-8 -*-

import os
import sys
import gazu
import maya.cmds as cmds
from PySide2 import QtWidgets, QtCore
from PySide2.QtWidgets import QMainWindow
from maya import mel
from pymel.core import *

sys.path.insert(0, "/home/rapa/maya/scripts")

import import_and_setting_0804
import main_ui_ver3_5

reload(import_and_setting_0804)
reload(main_ui_ver3_5)

from main_ui_ver3_5 import Ui_MainWindow as ezui


gazu.client.set_host('http://192.168.3.117/api')
gazu.log_in('admin@netflixacademy.com', 'netflixacademy')

project_name = "SOEZ_TEST_2"
asset_name = '0804_ui_test_2'
output_type_name = 'MOV'
output_type_short_name = 'MOV'
status_name = 'Todo'
user_comment = '0804_ui_success_2 / ㄱㄱ'

project = gazu.project.get_project_by_name(project_name)
asset = gazu.asset.get_asset_by_name(project, asset_name)

task_type = None
task_types = gazu.task.all_task_types_for_project(project)
for task_type in task_types:
    if task_type['name'] == 'Shading' and task_type['for_entity'] == asset['type']:
        task_type = task_type
        break
task = gazu.task.get_task_by_name(asset, task_type)
working_file = gazu.files.new_working_file(task)
output_type = gazu.files.get_output_type_by_name('MOV')
output_file = gazu.files.new_entity_output_file(asset, output_type, task_type,
                                                'publish', working_file=working_file, revision=working_file['revision'])
if os.path.exists(working_file['path']) is False:
    os.makedirs(working_file['path'])
else:
    pass

status = None
all_status = gazu.task.all_task_statuses()
for st in all_status:
    if st.get('name') == status_name:
        out = st
        break
    if st.get('short_name') == status_name:
        out = st
        break


class MainWindow(QMainWindow, ezui):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)

        # button tests
        self.pushButton_import.clicked.connect(self.iands)
        self.pushButton_publish.clicked.connect(self.publish)
        self.pushButton_arnold_setting.clicked.connect(self.render_setting_clicked)
        self.pushButton_save_scene.clicked.connect(self.save_clicked)
        if cmds.ls(selection=True):
            self.label_selected_mesh_name.setText(cmds.ls(selection=True)[0])
        else:
            pass

    def iands(self):
        import_and_setting_0804.part2().import_camera()
        image_path = "/home/rapa/MayaAssets/asset_hdri/studio_small_09_4k.exr"
        import_and_setting_0804.part2().create_skydome_light(image_path)
        import_and_setting_0804.part2().switch_camera()
        import_and_setting_0804.part2().fit_selection_in_frame()
        import_and_setting_0804.part2().rotate_objects()
        import_and_setting_0804.part2().rotate_dome()

    def render_setting_clicked(self):
        mel.eval('unifiedRenderGlobalsWindow;')

    def save_clicked(self):
        path = self.lineEdit_scene_path.text()
        name = self.lineEdit_scene_name.text()
        representation = self.comboBox_scene_format.currentText()
        full_path = path + name + representation
        maya_path = os.path.dirname(full_path)
        if not os.path.exists(maya_path):
            os.makedirs(maya_path)
        cmds.file(rename=full_path)
        if representation == 'mb':
            cmds.file(save=True, type='mayaBinary', force=True)
            mel.eval('confirmDialog -title "Confirm" -message ".mb file saved Successfully"')
        else:
            cmds.file(save=True, type='mayaAscii', force=True)
            mel.eval('confirmDialog -title "Confirm" -message ".ma file saved Successfully"')

    def publish(self):
        path = self.lineEdit_scene_path.text()
        name = self.lineEdit_scene_name.text()
        representation = self.comboBox_scene_format.currentText()
        full_path = path + name + representation
        print('!'*50)

        command_input = \
            "/usr/autodesk/maya2020/bin/Render" \
            " -r arnold -rd %s/" \
            " -im %s" \
            " -s 1" \
            " -e 48" \
            " -b 1" \
            " -fnc %d" \
            " -of exr" \
            " -cam turntable_camera" \
            " -x 1920 -y 1080" \
            " %s" % (working_file['path'], asset_name, 3, full_path)

        print('!'*50)
        input_directory = working_file['path']
        image_sequence_name = asset_name
        num_text = '%04d'
        file_extension = 'exr'
        output_directory = working_file['path']
        output_name = '0801_test'
        output_vide_format = 'mov'

        vid_command_input = 'ffmpeg -i %s/%s.%s.%s %s/%s.%s' % (
            input_directory, image_sequence_name, num_text, file_extension, output_directory, output_name, output_vide_format)

        kitsu_upload_path = "%s/%s.%s" % (working_file['path'], output_name, output_vide_format)

        if os.system(command_input) == 0:
            print('render finished')
            print('starting mov convert')
            if os.system(vid_command_input) == 0:
                print('convert vid finished')
                comment = gazu.task.add_comment(task, '3d24de8b-b327-4c95-a469-392637497234', comment=user_comment)

                preview = gazu.task.add_preview(task, comment, preview_file_path=kitsu_upload_path)

                gazu.task.set_main_preview(preview['id'], 1)
                mel.eval('confirmDialog -title "Confirm" -message "Publish Finished Successfully"')


try:
    MainWindow.close()
    MainWindow.deleteLater()
except:
    pass

td = MainWindow()
td.show()

