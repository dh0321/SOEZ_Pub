# -*- coding: utf-8 -*-

import os
import sys
import gazu
import maya.cmds as cmds
from PySide2 import QtWidgets, QtCore
from PySide2.QtWidgets import QMainWindow, QFileDialog
from maya import mel
from pymel.core import *
from PySide2.QtGui import QPixmap, Qt
from pprint import pprint

sys.path.insert(0, "/home/rapa/maya/scripts")

import import_and_setting_0803
from main_ui_ver3_5 import Ui_MainWindow as ezui

gazu.client.set_host('http://192.168.3.117/api')
gazu.log_in('admin@netflixacademy.com', 'netflixacademy')

project_name = "SOEZ_TEST_2"
asset_name = 'first_ui'
output_type_name = 'MOV'
output_type_short_name = 'MOV'
status_name = 'Todo'
user_comment = 'real_!!!!'

project = gazu.project.get_project_by_name(project_name)
asset = gazu.asset.get_asset_by_name(project, asset_name)

task_type = None
task_types = gazu.task.all_task_types_for_project(project)
for task_type in task_types:
    if task_type['name'] == 'Shading' and task_type['for_entity'] == asset['type']:
        task_type = task_type
        break
task = gazu.task.get_task_by_name(asset, task_type)
working_file = gazu.files.new_working_file(task)
output_type = gazu.files.get_output_type_by_name('MOV')
output_file = gazu.files.new_entity_output_file(asset, output_type, task_type,
                                                'publish', working_file=working_file, revision=working_file['revision'])
if os.path.exists(working_file['path']) is False:
    os.makedirs(working_file['path'])
else:
    pass

status = None
all_status = gazu.task.all_task_statuses()
for st in all_status:
    if st.get('name') == status_name:
        out = st
        break
    if st.get('short_name') == status_name:
        out = st
        break


class MainWindow(QMainWindow, ezui):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)

        # button tests
        self.pushButton_import.clicked.connect(self.iands)
        self.pushButton_publish.clicked.connect(self.publish)
        self.pushButton_arnold_setting.clicked.connect(self.render_setting_clicked)
        self.pushButton_save_scene.clicked.connect(self.save_clicked)
        if cmds.ls(selection=True):
            self.label_selected_mesh_name.setText(cmds.ls(selection=True)[0])
        else:
            pass

    # hdri_tab
        # hdri_list_widget
        self.listWidget_change_hdri_img.clear()  # 초기화
        self.add_item_hdri_list()  # 생성
        self.listWidget_change_hdri_img.itemClicked.connect(self.hdri_list_clicked)

        # hdri_pub
        self.pushButton_hdri_path.clicked.connect(self.pushButton_hdri_path_clicked)
        self.pushButton_publish_hdri_img.clicked.connect(self.pushButton_publish_hdri_img_clicked)

    def add_item_hdri_list(self):
        self.hdris = gazu.asset.all_assets_for_project(project["id"])
        pprint(self.hdris)
        hdri_list = []
        for hdri in self.hdris:
            self.listWidget_change_hdri_img.addItem(hdri['name'])
        #     hdri_list.append(hdri['name'])
        #
        # print(hdri_list)
        # print(type(hdri_list))
        # self.listWidget_change_hdri_img.addItem(hdri_list)

    def hdri_list_clicked(self):
        selected_item = self.listWidget_change_hdri_img.currentItem().text()
        print(selected_item)
        preview_file_id = None
        for hdri in self.hdris:
            if selected_item == hdri["name"]:
                preview_file_id = hdri['preview_file_id']

        print(preview_file_id)

        # 다운로드 함수에 필요한 프리뷰 파일의 아이디를 확인하기 위한 변수
        gp = gazu.files.get_preview_file(preview_file_id)
        print(gp)

        # 다운로드 함수에 필요한 프리뷰 파일패스를 확인하기 위한 변수
        self.dpp = '/home/rapa/test/' + gp['original_name'] + '.' + gp['extension']
        print(self.dpp)

        # 실질적으로 다운로드 해주는 함수
        dp = gazu.files.download_preview_file(preview_file=preview_file_id, file_path=self.dpp)
        print('suc', dp)

        # label을 변경
        self.change_label_preview_hdri_img_import()

    def change_label_preview_hdri_img_import(self):
        hdri_img_to_view = QPixmap(self.dpp)
        scaled_hdri_img_to_view = hdri_img_to_view.scaled(self.label_preview_hdri_img_import.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.label_preview_hdri_img_import.setPixmap(scaled_hdri_img_to_view)
        # self.label_preview_hdri_img_import.setPixmap(QPixmap(self.dpp).scaled(self.label_preview_hdri_img_import.size()))

        print("change")

    def pushButton_hdri_path_clicked(self):
        options = QFileDialog.Options()
        self.file_name, _ = QFileDialog.getOpenFileName(self, "Open Image", "",
                                                   ".exr(*.exr);; image(*.png *.svg *.jpg);;All Files (*)", options=options)
        if self.file_name:
            print("Selected file path:", self.file_name)

        self.lineEdit_hdri_path.setText(self.file_name)

        self.change_label_preview_hdri_img_add()

    def change_label_preview_hdri_img_add(self):
        hdri_img_to_view = QPixmap(self.file_name)
        scaled_hdri_img_to_view = hdri_img_to_view.scaled(self.label_preview_hdri_img_import.size(), Qt.KeepAspectRatio,
                                                          Qt.SmoothTransformation)
        self.label_preview_hdri_img_add.setPixmap(scaled_hdri_img_to_view)
        print("change")

    def pushButton_publish_hdri_img_clicked(self):

        # asset_type
        all_asset_types = gazu.asset.all_asset_types_for_project(project)
        for asset_type in all_asset_types:
            if "Environment" == asset_type["name"]:
                asset_type_id = asset_type['id']

        if self.file_name:
            # 파일 경로에서 파일 이름만 추출합니다.
            file_name_only = os.path.basename(self.file_name)

        gazu.asset.new_asset(project=project, asset_type=asset_type_id, name=file_name_only)


        asset = gazu.asset.get_asset_by_name(project, file_name_only)
        user_comment = "happy~ happy~ happy~ lala~ lala~ la~ la~ "

        # task_type
        all_task_types = gazu.task.all_task_types_for_project(project)
        for task_type in all_task_types:
            if task_type['name'] == 'Shading' and task_type['for_entity'] == asset['type']:
                upload_task_type = task_type
                break
        gazu.task.new_task(asset, upload_task_type)
        task = gazu.task.get_task_by_name(asset, upload_task_type)
        # working_file = gazu.files.new_working_file(task)
        kitsu_upload_path = "%s" % self.file_name
        comment = gazu.task.add_comment(task, '3d24de8b-b327-4c95-a469-392637497234', comment=user_comment)
        preview = gazu.task.add_preview(task, comment, preview_file_path=kitsu_upload_path)
        gazu.task.set_main_preview(preview['id'])

    def iands(self):
        import_and_setting_0803.part2().import_camera()
        image_path = self.dpp
        import_and_setting_0803.part2().create_skydome_light(image_path)
        import_and_setting_0803.part2().switch_camera()
        import_and_setting_0803.part2().fit_selection_in_frame()
        import_and_setting_0803.part2().rotate_objects()
        import_and_setting_0803.part2().rotate_dome()

    def render_setting_clicked(self):
        mel.eval('unifiedRenderGlobalsWindow;')

    def save_clicked(self):
        path = self.lineEdit_scene_path.text()
        name = self.lineEdit_scene_name.text()
        representation = self.comboBox_scene_format.currentText()
        full_path = path + name + representation
        maya_path = os.path.dirname(full_path)
        if not os.path.exists(maya_path):
            os.makedirs(maya_path)
        cmds.file(rename=full_path)
        if representation == 'mb':
            cmds.file(save=True, type='mayaBinary', force=True)
            mel.eval('confirmDialog -title "Confirm" -message ".mb file saved Successfully"')
        else:
            cmds.file(save=True, type='mayaAscii', force=True)
            mel.eval('confirmDialog -title "Confirm" -message ".ma file saved Successfully"')

    def publish(self):
        path = self.lineEdit_scene_path.text()
        name = self.lineEdit_scene_name.text()
        representation = self.comboBox_scene_format.currentText()
        full_path = path + name + representation
        print('!'*50)

        command_input = \
            "/usr/autodesk/maya2020/bin/Render" \
            " -r arnold -rd %s/" \
            " -im %s" \
            " -s 1" \
            " -e 48" \
            " -b 1" \
            " -fnc %d" \
            " -of exr" \
            " -cam turntable_camera" \
            " -x 1920 -y 1080" \
            " %s" % (working_file['path'], asset_name, 3, full_path)

        print('!'*50)
        input_directory = working_file['path']
        image_sequence_name = asset_name
        num_text = '%04d'
        file_extension = 'exr'
        output_directory = working_file['path']
        output_name = '0803_first_test'
        output_vide_format = 'mov'

        vid_command_input = 'ffmpeg -i %s/%s.%s.%s %s/%s.%s' % (
            input_directory, image_sequence_name, num_text, file_extension, output_directory, output_name, output_vide_format)

        kitsu_upload_path = "%s/%s.%s" % (working_file['path'], output_name, output_vide_format)

        if os.system(command_input) == 0:
            print('render finished')
            print('starting mov convert')
            if os.system(vid_command_input) == 0:
                print('convert vid finished')
                comment = gazu.task.add_comment(task, '3d24de8b-b327-4c95-a469-392637497234', comment=user_comment)

                preview = gazu.task.add_preview(task, comment, preview_file_path=kitsu_upload_path)

                gazu.task.set_main_preview(preview['id'], 1)
                mel.eval('confirmDialog -title "Confirm" -message "Publish Finished Successfully"')


