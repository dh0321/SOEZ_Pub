from PySide2 import QtCore, QtWidgets
from PySide2.QtWidgets import QApplication, QMainWindow

import sys
sys.path.insert(0, "/home/rapa/MayaProjects/importsettings1/scripts")

from soez_main_ver2_1 import Ui_MainWindow

class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)

if __name__ == "__main__":

    try:
        MainWindow.close()
        MainWindow.deleteLater()
    except:
        pass

    td = MainWindow()
    td.show()
