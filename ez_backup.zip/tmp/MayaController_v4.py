# -*- coding: utf-8 -*-

import os
import sys
import gazu
import maya.cmds as cmds
from PySide2 import QtWidgets, QtCore
from PySide2.QtWidgets import QMainWindow
from maya import mel
from pymel.core import *

sys.path.insert(0, "/home/rapa/MayaProjects/importsettings1/scripts")

import import_and_setting_0807
import main_ui_ver3_6

reload(import_and_setting_0807)
reload(main_ui_ver3_6)

from main_ui_ver3_6 import Ui_MainWindow as ezui


class MainWindow(QMainWindow, ezui):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)

        gazu.client.set_host('http://192.168.3.117/api')
        gazu.log_in('admin@netflixacademy.com', 'netflixacademy')

        self.project_name = "SOEZ_TEST_2"
        self.asset_name = '0801_maya_ui_test'
        self.output_type_name = 'MOV'
        self.output_type_short_name = 'MOV'
        self.status_name = 'Todo'
        self.user_comment = '0801_maya_ui_success => main_ui_ver3_4.Ui_MainWindow.textEdit_leave_a_comment.text()'

        self.project = None
        self.asset = None
        self.task_type = None
        self.task = None
        self.working_file = None
        self.working_revision = None
        self.output_type = None
        self.output_file = None
        self.output_revision = None
        self.status = None

        # input variable
        self.start_frame = 1001
        self.end_frame = 1024

        self.path = None
        self.name = None
        self.representation = None
        self.full_path = None

        # button tests
        self.pushButton_import.clicked.connect(self.iands)
        self.pushButton_publish.clicked.connect(self.publish)
        self.pushButton_arnold_setting.clicked.connect(self.render_setting_clicked)
        self.pushButton_save_scene.clicked.connect(self.save_clicked)
        self.checkBox_change_setting.stateChanged.connect(self.chbxStateChange)

        self.lineEdit_mesh_start_frame.textChanged.connect(self.change_frame_value) #textChanged > set method?
        self.lineEdit_mesh_end_frame.textChanged.connect(self.change_frame_value) #textChanged > set method?

        # Kitsu Publist ---------------------------------------
        # Set listWidget project and asset name
        self.all_project_infos = gazu.project.all_projects()
        self.set_projects_list()
        self.set_assets_list_by_project()

        # change the item (project) to connect to the method that outputs the currently selected text.
        self.listWidget_vid_project.currentItemChanged.connect(
            self.set_assets_list_by_project)  # == itemClicked
        self.listWidget_vid_project.itemChanged.connect(self.set_assets_list_by_project)  # == itemClicked
        self.listWidget_vid_asset.currentItemChanged.connect(self.set_current_asset_text)  # == itemClicked
        self.listWidget_vid_asset.itemChanged.connect(self.set_current_asset_text)  # == itemClicked

        self.pushButton_publish.clicked.connect(self.kitsu_publish)
        self.commandLinkButton_go_kitsu.clicked.connect(self.go_kitsu)
        # -----------------------------------------------------

        if cmds.ls(selection=True):
            self.label_selected_mesh_name.setText(cmds.ls(selection=True)[0])
            self.label_selected_camera_name.setText("turntable_camera")
        else:
            #mel.eval('confirmDialog -title "report" -message "please select the mesh first" -button "Ok"')
            button_result = cmds.confirmDialog(title="report", message="please select the mesh first", messageAlign="center", button="confirm")
            print(button_result)
            if button_result == "confirm":
                #QtCore.QCoreApplication.instance().quit()
                #maya.utils.executeDeferred(self.exit_ui)
                #cmds.deleteUI(ezui.setupUi)
                pass


    # gazu function section
    def get_project(self):
        self.project_name = self.current_project_text
        # self.project_name = "SOEZ_TEST_2"  # test
        self.project = gazu.project.get_project_by_name(self.project_name)
        # self.project = gazu.project.all_projects()
        return self.project

    def get_asset(self):
        self.asset_name = self.current_asset_text
        # self.asset_name = '0801_maya_ui_test'  # test
        self.asset = gazu.asset.get_asset_by_name(self.project, self.asset_name)
        return self.asset

    def get_task_type(self):
        task_types = gazu.task.all_task_types_for_project(self.project)
        for task_type in task_types:
            if task_type['name'] == 'Shading' and task_type['for_entity'] == self.asset['type']:
                self.task_type = task_type
                break
        return self.task_type

    def get_task(self):
        self.task = gazu.task.get_task_by_name(self.asset, self.task_type)
        return self.task

    def create_working_file(self):
        self.working_file = gazu.files.new_working_file(self.task)
        return self.working_file

    def get_working_revision(self):
        self.working_revision = self.working_file['revision']
        return self.working_revision

    def get_output_type(self):
        # set_output_type
        self.current_output_type_name = self.lineEdit_vid_format.text().upper()
        self.current_output_type_short_name = self.lineEdit_vid_format.text().lower()

        self.output_type_name = self.current_output_type_name
        self.output_type_short_name = self.current_output_type_short_name

        # self.output_type_name = 'MOV'  # test
        self.output_type = gazu.files.new_output_type(self.output_type_name, self.output_type_short_name)
        self.output_type = gazu.files.get_output_type_by_name(self.output_type_name)
        return self.output_type

    def create_output_file(self):
        self.output_file = gazu.files.new_entity_output_file(self.asset, self.output_type, self.task_type,
                                                             comment='publish', working_file=self.working_file,
                                                             revision=self.working_file['revision'])
        return self.output_file

    def get_output_revision(self):
        self.output_revision = self.output_file['revision']
        return self.output_revision

    def create_dir(self):
        if os.path.exists(self.working_file['path']) is False:
            os.makedirs(self.working_file['path'])
        else:
            pass

    def get_status(self):
        self.status_name = 'Todo'  # test
        all_status = gazu.task.all_task_statuses()
        for st in all_status:
            if st.get('name') == self.status_name or st.get('short_name') == self.status_name:
                self.status = st
                break
        return self.status

    def get_comment(self):
        self.current_user_comment = self.textEdit_leave_a_comment.toPlainText()
        self.user_comment = self.current_user_comment

    def get_kitsu_upload_path(self):
        # If all three values are equal to the default
        if self.lineEdit_vid_path.text() == self.working_file['path'] \
                and self.lineEdit_vid_name.text() == self.output_name \
                and self.lineEdit_vid_format.text() == self.output_vide_format:
            self.kitsu_upload_path = "%s/%s.%s" % (self.working_file['path'], self.output_name, self.output_vide_format)

        # If any of the three is not the default value
        else:
            output_dir = self.lineEdit_vid_path.text() # 셋 중 하나라도 기본값이면 기본값 그대로 어차피 text()로 추출될 것
            output_name = self.lineEdit_vid_name.text()
            output_extension = self.lineEdit_vid_format.text()

            self.current_output_file_path = "%s%s.%s" % (output_dir, output_name, output_extension)
            self.kitsu_upload_path = self.current_output_file_path

    # Maya Function ---------

    def change_frame_value(self):
        self.start_frame = int(self.lineEdit_mesh_start_frame.text())
        self.end_frame = int(self.lineEdit_mesh_end_frame.text())


    def chbxStateChange(self):
        print("isChecked", self.checkBox_change_setting.isChecked)
        if self.checkBox_change_setting.isChecked():
            print('setEnabled  True')
            self.lineEdit_mesh_start_frame.setEnabled(True)
            self.lineEdit_mesh_end_frame.setEnabled(True)
            self.lineEdit_img_format.setEnabled(True)
            self.lineEdit_vid_format.setEnabled(True)
            self.lineEdit_img_name.setEnabled(True)
            self.lineEdit_img_path.setEnabled(True)
            self.lineEdit_vid_name.setEnabled(True)
            self.lineEdit_vid_path.setEnabled(True)

        else:
            print('setEnabled  False')
            self.lineEdit_mesh_start_frame.setDisabled(True)
            self.lineEdit_mesh_end_frame.setDisabled(True)
            self.lineEdit_img_format.setDisabled(True)
            self.lineEdit_vid_format.setDisabled(True)
            self.lineEdit_img_name.setDisabled(True)
            self.lineEdit_img_path.setDisabled(True)
            self.lineEdit_vid_name.setDisabled(True)
            self.lineEdit_vid_path.setDisabled(True)

    def iands(self):
        import_and_setting_0807.part2().import_camera()
        image_path = "/home/rapa/MayaAssets/assets_hdri/little_paris_under_tower_4k.exr"
        import_and_setting_0807.part2().create_skydome_light(image_path)
        import_and_setting_0807.part2().switch_camera()
        import_and_setting_0807.part2().fit_selection_in_frame()
        import_and_setting_0807.part2().rotate_objects(self.start_frame, self.end_frame)
        import_and_setting_0807.part2().rotate_dome(self.start_frame, self.end_frame)

    def render_setting_clicked(self):
        mel.eval('unifiedRenderGlobalsWindow;')

    def save_clicked(self):
        self.path = self.lineEdit_scene_path.text()
        self.name = self.lineEdit_scene_name.text()
        self.representation = self.comboBox_scene_format.currentText()
        self.full_path = self.path + self.name + self.representation
        maya_path = os.path.dirname(self.full_path)
        if not os.path.exists(maya_path):
            os.makedirs(maya_path)
        cmds.file(rename=self.full_path)
        if self.representation == '.mb':
            cmds.file(save=True, type='mayaBinary', force=True)
            mel.eval('confirmDialog -title "Confirm" -message ".mb file saved Successfully"')
        else:
            cmds.file(save=True, type='mayaAscii', force=True)
            mel.eval('confirmDialog -title "Confirm" -message ".ma file saved Successfully"')

        return self.path, self.name, self.full_path

    def set_current_project_text(self):
        print("-------set_current_project_text------")
        self.current_project_text = self.listWidget_vid_project.currentItem().text()
        print("current_project_text : ", self.current_project_text)

    def set_current_asset_text(self):
        print("-------set_current_asset_text------")
        if self.listWidget_vid_asset.currentItem():
            self.current_asset_text = self.listWidget_vid_asset.currentItem().text()
        else:
            self.listWidget_vid_asset.setCurrentItem(self.listWidget_vid_asset.item(0))
            self.current_asset_text = self.listWidget_vid_asset.currentItem().text()
        print("current_asset_text : ", self.current_asset_text)

    def set_projects_list(self):
        print("-------set_projects_list------")
        self.listWidget_vid_project.clear()
        for project_infos in self.all_project_infos:
            # print(project_infos['name'])
            self.listWidget_vid_project.addItem(project_infos['name'])
        # Select the first project by default. = error prevention
        self.listWidget_vid_project.setCurrentItem(self.listWidget_vid_project.item(0))


    def set_assets_list_by_project(self):
        print("-------set_assets_list_by_project------")
        self.listWidget_vid_asset.clear()
        self.set_current_project_text()
        for project_infos in self.all_project_infos:
            if project_infos["name"] == self.current_project_text:
                assets_info = gazu.asset.all_assets_for_project(project_infos["id"])
                if assets_info:
                    for asset in assets_info:
                        self.listWidget_vid_asset.addItem(asset["name"])
                else:
                    self.listWidget_vid_asset.addItem("no asset")
        self.listWidget_vid_asset.setCurrentItem(self.listWidget_vid_asset.item(0))
        self.set_current_asset_text()


    def publish(self):
        print("-------kitsu_publish------")


        #call function
        self.get_project()
        self.get_asset()
        self.get_task_type()
        self.get_task()
        self.create_working_file()
        self.get_working_revision()
        self.get_output_type()
        self.create_output_file()
        self.get_output_revision()
        self.create_dir()
        self.get_status()
        self.get_comment()
        self.get_kitsu_upload_path()
        # 리스트위젯에 선택된 프로젝트와 어셋네임을 워킹파일 경로로 받을 수 있도록 만들어야 함
        # 그다음에 워킹파일이 ui의 라인에딧 내용에 셋텍스트되도록 해야함

        # 아래의 내용 if self.lineEdit_img_path != self.working_file['path']:
        # 과 위에 내가 만든 self.get_kitsu_upload_path() 의 내용이 겹치지 않는지 점검필요

        if self.lineEdit_img_path != self.working_file['path']:
            custom_ren_path = self.lineEdit_img_path.text()
        else:
            ren_path = self.working_file['path']
        self.ren_asset_name = "<%s>_<%s>_<%s>" % (self.project['name'], self.asset['name'], self.working_revision)
        image_format = self.lineEdit_img_format.text()  # "exr"
        print('!' * 50)
        print(self.ren_asset_name)

        command_input = \
            "/usr/autodesk/maya2020/bin/Render" \
            " -r arnold -rd %s/" \
            " -im %s" \
            " -s 1" \
            " -e 48" \
            " -b 1" \
            " -fnc 3" \
            " -of %s" \
            " -cam turntable_camera" \
            " -x 1920 -y 1080" \
            " %s" % (ren_path, self.ren_asset_name, image_format, self.full_path)

        custom_command_input = \
            "/usr/autodesk/maya2020/bin/Render" \
            " -r arnold -rd %s/" \
            " -im %s" \
            " -s 1" \
            " -e 48" \
            " -b 1" \
            " -fnc 3" \
            " -of %s" \
            " -cam turntable_camera" \
            " -x 1920 -y 1080" \
            " %s" % (custom_ren_path, self.ren_asset_name, image_format, self.full_path)

        print('!' * 50)
        input_directory = ren_path
        image_sequence_name = self.ren_asset_name
        num_text = '%04d'
        file_extension = image_format  # 'exr'
        output_directory = self.working_file['path']
        self.output_name = "<%s>_<%s>_<%s>" % (self.project_name, self.asset_name, self.output_revision)

        # Create a get_output_type method so you don't need it
        # self.output_vide_format = self.lineEdit_vid_format.text()  # 'mov'

        vid_command_input = 'ffmpeg -i %s/%s.%s.%s %s/%s.%s' % (
            input_directory, image_sequence_name, num_text, file_extension, output_directory, self.output_name,
            self.output_vide_format)


        if self.lineEdit_img_path.textChanged():
            os.system(custom_command_input)
        if os.system(command_input) == 0:
            print('render finished')
            print('starting mov convert')
            if os.system(vid_command_input) == 0:
                print('convert vid finished')
                comment = gazu.task.add_comment(self.task, '3d24de8b-b327-4c95-a469-392637497234', comment=self.user_comment)

                preview = gazu.task.add_preview(self.task, comment, preview_file_path=self.kitsu_upload_path)

                gazu.task.set_main_preview(preview['id'], 1)
                mel.eval('confirmDialog -title "Confirm" -message "Publish Finished Successfully"')




if __name__ == "__main__":

    try:
        MainWindow.close()
        MainWindow.deleteLater()
    except:
        pass

    td = MainWindow()
    td.show()
