# -*- coding: utf-8 -*-

import os
import sys
import gazu
import maya.cmds as cmds
from PySide2 import QtWidgets, QtCore
from PySide2.QtWidgets import QMainWindow
from maya import mel
from pymel.core import *

sys.path.insert(0, "/home/rapa/MayaProjects/importsettings1/scripts")

import import_and_setting_0807
import main_ui_ver3_6

reload(import_and_setting_0807)
reload(main_ui_ver3_6)

from main_ui_ver3_6 import Ui_MainWindow as ezui


class MainWindow(QMainWindow, ezui):

    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)

        gazu.client.set_host('http://192.168.3.117/api')
        gazu.log_in('admin@netflixacademy.com', 'netflixacademy')

        self.project_name = "SOEZ_TEST_2"
        self.asset_name = '0801_maya_ui_test'
        self.output_type_name = 'MOV'
        self.output_type_short_name = 'MOV'
        self.status_name = 'Todo'
        self.user_comment = '0801_maya_ui_success => main_ui_ver3_4.Ui_MainWindow.textEdit_leave_a_comment.text()'

        self.project = None
        self.asset = None
        self.task_type = None
        self.task = None
        self.working_file = None
        self.working_revision = None
        self.output_type = None
        self.output_file = None
        self.output_revision = None
        self.status = None

        # input variable
        self.start_frame = 1001
        self.end_frame = 1024

        self.path = None
        self.name = None
        self.representation = None
        self.full_path = None

        # button tests
        self.pushButton_import.clicked.connect(self.iands)
        self.pushButton_publish.clicked.connect(self.publish)
        self.pushButton_arnold_setting.clicked.connect(self.render_setting_clicked)
        self.pushButton_save_scene.clicked.connect(self.save_clicked)
        self.checkBox_change_setting.stateChanged.connect(self.chbxStateChange)

        self.lineEdit_mesh_start_frame.textChanged.connect(self.change_frame_value)
        self.lineEdit_mesh_end_frame.textChanged.connect(self.change_frame_value)

        if cmds.ls(selection=True):
            self.label_selected_mesh_name.setText(cmds.ls(selection=True)[0])
            self.label_selected_camera_name.setText("turntable_camera")
        else:
            button_result = cmds.confirmDialog(title="Report", message="please select the mesh", messageAlign="center", button="confirm")
            print(button_result)
            if button_result == "confirm":
                MainWindow.close(self)
                sys.exit()


    # gazu function section

    def get_project(self):
        self.project_name = "SOEZ_TEST_2"  # test
        self.project = gazu.project.get_project_by_name(self.project_name)
        # self.project = gazu.project.all_projects()
        return self.project

    def get_asset(self):
        self.project_name = "SOEZ_TEST_2"  # test
        self.asset_name = '0801_maya_ui_test'  # test
        self.asset = gazu.asset.get_asset_by_name(self.project, self.asset_name)
        return self.asset

    def get_task_type(self):
        task_types = gazu.task.all_task_types_for_project(self.project)
        for task_type in task_types:
            if task_type['name'] == 'Shading' and task_type['for_entity'] == self.asset['type']:
                self.task_type = task_type
                break
        return self.task_type

    def get_task(self):
        self.task = gazu.task.get_task_by_name(self.asset, self.task_type)
        return self.task

    def create_working_file(self):
        self.working_file = gazu.files.new_working_file(self.task)
        return self.working_file

    def get_working_revision(self):
        self.working_revision = self.working_file['revision']
        return self.working_revision

    def get_output_type(self):
        self.output_type_name = 'MOV'  # test
        self.output_type = gazu.files.get_output_type_by_name(self.output_type_name)
        return self.output_type

    def create_output_file(self):
        self.output_file = gazu.files.new_entity_output_file(self.asset, self.output_type, self.task_type,
                                                             comment='publish', working_file=self.working_file,
                                                             revision=self.working_file['revision'])
        return self.output_file

    def get_output_revision(self):
        self.output_revision = self.output_file['revision']
        return self.output_revision

    def create_dir(self):
        if os.path.exists(self.working_file['path']) is False:
            os.makedirs(self.working_file['path'])
        else:
            pass

    def get_status(self):
        self.status_name = 'Todo'  # test
        all_status = gazu.task.all_task_statuses()
        for st in all_status:
            if st.get('name') == self.status_name or st.get('short_name') == self.status_name:
                self.status = st
                break
        return self.status

    # Maya Function ---------

    def change_frame_value(self):
        self.start_frame = int(self.lineEdit_mesh_start_frame.text())
        self.end_frame = int(self.lineEdit_mesh_end_frame.text())

        return self.start_frame, self.end_frame

    def chbxStateChange(self):
        print("isChecked", self.checkBox_change_setting.isChecked)
        if self.checkBox_change_setting.isChecked():
            print('setEnabled  True')
            self.lineEdit_mesh_start_frame.setEnabled(True)
            self.lineEdit_mesh_end_frame.setEnabled(True)
            self.lineEdit_img_format.setEnabled(True)
            self.lineEdit_vid_format.setEnabled(True)
            self.lineEdit_img_name.setEnabled(True)
            self.lineEdit_img_path.setEnabled(True)
            self.lineEdit_vid_name.setEnabled(True)
            self.lineEdit_vid_path.setEnabled(True)

        else:
            print('setEnabled  False')
            self.lineEdit_mesh_start_frame.setDisabled(True)
            self.lineEdit_mesh_end_frame.setDisabled(True)
            self.lineEdit_img_format.setDisabled(True)
            self.lineEdit_vid_format.setDisabled(True)
            self.lineEdit_img_name.setDisabled(True)
            self.lineEdit_img_path.setDisabled(True)
            self.lineEdit_vid_name.setDisabled(True)
            self.lineEdit_vid_path.setDisabled(True)

    def iands(self):
        # print("[frame]", self.start_frame, self.end_frame)
        import_and_setting_0807.part2().import_camera()
        image_path = "/home/rapa/MayaAssets/assets_hdri/little_paris_under_tower_4k.exr"
        import_and_setting_0807.part2().create_skydome_light(image_path)
        import_and_setting_0807.part2().switch_camera()
        import_and_setting_0807.part2().fit_selection_in_frame()
        import_and_setting_0807.part2().rotate_objects(self.start_frame, self.end_frame)
        import_and_setting_0807.part2().rotate_dome(self.start_frame, self.end_frame)

    def render_setting_clicked(self):
        mel.eval('unifiedRenderGlobalsWindow;')

    def save_clicked(self):
        self.path = self.lineEdit_scene_path.text()
        self.name = self.lineEdit_scene_name.text()
        self.representation = self.comboBox_scene_format.currentText()
        self.full_path = self.path + self.name + self.representation
        maya_path = os.path.dirname(self.full_path)
        if not os.path.exists(maya_path):
            os.makedirs(maya_path)
        cmds.file(rename=self.full_path)
        if self.representation == '.mb':
            cmds.file(save=True, type='mayaBinary', force=True)
            mel.eval('confirmDialog -title "Confirm" -message ".mb file saved Successfully"')
        else:
            cmds.file(save=True, type='mayaAscii', force=True)
            mel.eval('confirmDialog -title "Confirm" -message ".ma file saved Successfully"')

        return self.path, self.name, self.full_path

    def publish(self):

        #call function
        self.get_project()
        self.get_asset()
        self.get_task_type()
        self.get_task()
        self.create_working_file()
        self.get_working_revision()
        self.get_output_type()
        self.create_output_file()
        self.get_output_revision()
        self.create_dir()
        self.get_status()

        print(self.working_file['path'])

        # if self.lineEdit_img_path != self.working_file['path']:
        #     custom_ren_path = self.lineEdit_img_path.text()
        # else:
        #     ren_path = self.working_file['path']
        # self.ren_asset_name = "<%s>_<%s>_<%s>" % (self.project['name'], self.asset['name'], self.working_revision)
        # image_format = self.lineEdit_img_format.text()  # "exr"
        # print('!' * 50)
        # print(self.ren_asset_name)
        #
        # command_input = \
        #     "/usr/autodesk/maya2020/bin/Render" \
        #     " -r arnold -rd %s/" \
        #     " -im %s" \
        #     " -s 1" \
        #     " -e 48" \
        #     " -b 1" \
        #     " -fnc 3" \
        #     " -of %s" \
        #     " -cam turntable_camera" \
        #     " -x 1920 -y 1080" \
        #     " %s" % (ren_path, self.ren_asset_name, image_format, self.full_path)
        #
        # custom_command_input = \
        #     "/usr/autodesk/maya2020/bin/Render" \
        #     " -r arnold -rd %s/" \
        #     " -im %s" \
        #     " -s 1" \
        #     " -e 48" \
        #     " -b 1" \
        #     " -fnc 3" \
        #     " -of %s" \
        #     " -cam turntable_camera" \
        #     " -x 1920 -y 1080" \
        #     " %s" % (custom_ren_path, self.ren_asset_name, image_format, self.full_path)
        #
        # print('!' * 50)
        # input_directory = ren_path
        # image_sequence_name = self.ren_asset_name
        # num_text = '%04d'
        # file_extension = image_format  # 'exr'
        # output_directory = self.working_file['path']
        # output_name = "<%s>_<%s>_<%s>" % (self.project_name, self.asset_name, self.output_revision)
        # output_vide_format = self.lineEdit_vid_format.text()  # 'mov'
        #
        # vid_command_input = 'ffmpeg -i %s/%s.%s.%s %s/%s.%s' % (
        #     input_directory, image_sequence_name, num_text, file_extension, output_directory, output_name,
        #     output_vide_format)
        #
        # kitsu_upload_path = "%s/%s.%s" % (self.working_file['path'], output_name, output_vide_format)
        #
        # if self.lineEdit_img_path.textChanged():
        #     os.system(custom_command_input)
        # if os.system(command_input) == 0:
        #     print('render finished')
        #     print('starting mov convert')
        #     if os.system(vid_command_input) == 0:
        #         print('convert vid finished')
        #         comment = gazu.task.add_comment(self.task, '3d24de8b-b327-4c95-a469-392637497234', comment=self.user_comment)
        #
        #         preview = gazu.task.add_preview(self.task, comment, preview_file_path=kitsu_upload_path)
        #
        #         gazu.task.set_main_preview(preview['id'], 1)
        #         mel.eval('confirmDialog -title "Confirm" -message "Publish Finished Successfully"')
        #



if __name__ == "__main__":

    try:
        MainWindow.close()
        MainWindow.deleteLater()
    except:
        pass

    td = MainWindow()
    td.show()
