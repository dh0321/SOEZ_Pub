# AOV 쪽에 렌더 패스 추가
from maya import mel
from mtoa import aovs
import main_ui_ver3_6
from main_ui_ver3_6 import Ui_MainWindow as ezui

# List Widget 2개로 구성하여, 하나는 Available AOVs, Active AOVs 로 설정하여,
# Available AOVs 에서 클릭된 것들을 Active AOVs 로 넘겨준다.


def set_aov():
    available_aovs = [
        'albedo', 'background', 'coat', 'diffuse', 'direct', 'emission', 'indirect', 'motionvector',
        'opactiy', 'RGBA', 'sheen', 'specular', 'transmission', 'volume'
    ]

    avail_listwidget.addItems(available_aovs)
    active_listwidget.append.clicked.connect(from_avail_listwidget.item)
    newAov.addAOV(clicked_item)

    # 아래 지정된 이름의 AOV 들을 각각 추가해준다.
    # 아래의 AOV 들은 default 로 추가해주면 좋은 값이다.
    newAov = aovs.AOVInterface()
    newAov.addAOV("diffuse")
    newAov.addAOV("specular")
    newAov.addAOV("RGBA")


def set_render_sampling():
    # 따로 class 변수 지정은 안해도 될 듯

    # 아래 코드들을 통해 마지막에 입력된 숫자만큼 렌더 샘플링 설정이 가능하다
    # 모든 값들은 0~10 사이의 값을 가진다. 하지만, AASamples 는 다르게 -3~10 의 값을 가질 수 있다.
    # 각각 값의 label 이름은 옆의 코멘트와 같다
    # 입력된 값들은 default 로 설정하면 좋은 통상 최적화 된 이미지를 뽑는데 좋은 값이다.

    # set values
    aa_sam = line_edit_01.setDefault_to_8
    diffuse_sam = line_edit_02.setDefault_to_6
    specular_sam = line_edit_03.setDefault_to_4
    trans_sam = line_edit_04.setDefault_to_4
    sss_sam = line_edit_05.setDefault_to_2
    volume_sam = line_edit_06.setDefault_to_2

    # setting code
    mel.eval('setAttr "defaultArnoldRenderOptions.AASamples" %s;') % aa_sam  # -3~10 까지만 세팅 가능 Camera(AA)
    mel.eval('setAttr "defaultArnoldRenderOptions.GIDiffuseSamples" %s;') % diffuse_sam  # Diffuse
    mel.eval('setAttr "defaultArnoldRenderOptions.GISpecularSamples" %s;') % specular_sam  # Specular
    mel.eval('setAttr "defaultArnoldRenderOptions.GITransmissionSamples" %s;') % trans_sam  # Transmission
    mel.eval('setAttr "defaultArnoldRenderOptions.GISssSamples" %s;') % sss_sam  # SSS
    mel.eval('setAttr "defaultArnoldRenderOptions.GIVolumeSamples" %s;') % volume_sam  # Volume Indirect

