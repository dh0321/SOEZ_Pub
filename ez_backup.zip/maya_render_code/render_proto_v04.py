import os
import sys
import gazu
import tmp

sys.path.insert(0, "/home/rapa/maya/scripts")

# from maya import mel
# from MayaController_v03_4 import *
# from ui_v3 import main_ui_ver3_4
# from main_ui_ver3_4 import Ui_MainWindow as ezui



gazu.client.set_host('http://192.168.3.117/api')
gazu.log_in('admin@netflixacademy.com', 'netflixacademy')

# set_gazu
project_name = "SOEZ_TEST_2"
asset_name = '0801_maya_ui_test'
output_type_name = 'MOV'
output_type_short_name = 'MOV'
status_name = 'Todo'
# 아래 부분은 ui 상에서 유저가 입력하는 텍스트를 받게끔
user_comment = '0801_maya_ui_success => main_ui_ver3_4.Ui_MainWindow.textEdit_leave_a_comment.text()'
# 아래 부분은 업로드할 파일을 지정해주는 경로
# file_path = '/home/rapa/maya_test/cog_asset_v01/ren_mov/cog_v01.mov'

# gazu_func
project = gazu.project.get_project_by_name(project_name)
print(f'project :{project}')
asset = gazu.asset.get_asset_by_name(project, asset_name)
print(f'asset: {asset}')

# find task and set new_working_file
task_type = None
task_types = gazu.task.all_task_types_for_project(project)
print(f'task types: {task_types}')
for task_type in task_types:
    if task_type['name'] == 'Shading' and task_type['for_entity'] == asset['type']:
        task_type = task_type
        break
task = gazu.task.get_task_by_name(asset, task_type)
print(f'task: {task}')
working_file = gazu.files.new_working_file(task)
# working_file = gazu.files.get_working_files_for_task(task)
print(f'working_file: {working_file}')
output_type = gazu.files.get_output_type_by_name('MOV')
print(f'output_type : {output_type}')
# output_file = gazu.files.new_entity_output_file(task['entity_id'], output_type=output_type['id'],
#                                                 task_type=task['task_type_id'], comment=user_comment)
output_file = gazu.files.new_entity_output_file(asset, output_type, task_type,
                                                'publish', working_file=working_file, revision=working_file['revision'])

# gazu.files.new_entity_output_file(asset, output_type, task_type,
#                                   'publish', working_file=working_file, revision=output_file['revision'])
# output_file = gazu.files.get_output_file('1522975d-5ee6-45ee-a7c4-520d9bfb0271')
print(f'output_file: {output_file}')

# create working dir
if os.path.exists(working_file['path']) is False:
    os.makedirs(working_file['path'])
else:
    pass

# create output dir
if os.path.exists(output_file['path']) is False:
    os.makedirs(output_file['path'])
else:
    pass

# set render
# command_input = \
#     f"/usr/autodesk/maya2020/bin/Render" \
#     f" -r arnold -rd %s/" \
#     " -im %s" \
#     " -of exr" \
#     " -s 1" \
#     " -e 24" \
#     " -b 1" \
#     " -pad 4" \
#     " -cam turntable_camera" \
#     " -x 1920 -y 1080" \
#     " %s" % (working_file['path'], asset_name, MayaController_v03_4.MainWindow.full_path)

'''
command_input = \
    "/usr/autodesk/maya2020/bin/Render" \
    " -r arnold -rd {render_out_directory}" \
    " -im {file_name}" \
    " -of {file_format=exr}" \
    " -s {start_frame=1}" \
    " -e {end_frame=24}" \
    " -b {frame_step=1}" \
    " -pad {frame_padding=4}" \
    " -cam {render_cam=turntable_camera}" \
    " -x {x_resolution=1920} -y {y_resolution=1080}" \
    " {render_scene_file=/home/rapa/maya_test/scene/command_batch_test.ma}"
'''

'''
vid_command_input =
        input_directory = self.lineEdit_img_path.text()
        image_sequence_name = self.lineEdit_img_name.text()
        num_text = self.lineEdit_num_text.text()
        file_extension = self.lineEdit_img_format.text()
        output_directory = self.lineEidt_video_path.text()
        output_name = self.lineEidt_video_name.text()
        output_vide_format = self.lineEdit_video_format.text()

        command_input = 'ffmpeg -i %s/%s.%s.%s %s/%s.%s' % (
            input_directory, image_sequence_name, num_text, file_extension, output_directory, output_name,
            output_vide_format)

        if os.system(command_input) == 0:
            mel.eval('confirmDialog -title "Confirm" -message "Convert Finished Successfully"')
        elif os.path.exists("%s/%s.%s" % (output_directory, output_name, output_vide_format)):
            mel.eval('confirmDialog -title "Confirm" -message "File already exists. Please give different name"')
        else:
            mel.eval('confirmDialog -title "Confirm" -message "There was an error"')
'''

input_directory = working_file['path']
image_sequence_name = '0801_test'
num_text = '%04d'
file_extension = 'exr'
output_directory = working_file['path']
output_name = '0801_test'
output_vide_format = 'mov'

vid_command_input = 'ffmpeg -i %s/%s.%s.%s %s/%s.%s' % (
    input_directory, image_sequence_name, num_text, file_extension, output_directory, output_name,
    output_vide_format)

kitsu_upload_path = "%s/%s.%s" % (working_file['path'], output_name, output_vide_format)

# kitsu upload


status = None
all_status = gazu.task.all_task_statuses()
print(f'all_status: {all_status}')
for st in all_status:
    if st.get('name') == status_name:
        out = st
        break
    if st.get('short_name') == status_name:
        out = st
        break

# comment = gazu.task.add_comment(task, '3d24de8b-b327-4c95-a469-392637497234', comment=user_comment)
# print(f'comment: {comment}')
# preview = gazu.task.add_preview(task, comment, preview_file_path=kitsu_upload_path)
# print(f'preview: {preview}')
#
# gazu.task.set_main_preview(kitsu_upload_path, 1)

# # execution
# if os.system(command_input) == 0:
#     print('render finished')
#     print('starting mov convert')
#     if os.system(vid_command_input) == 0:
#         print('convert vid finished')
#         comment = gazu.task.add_comment(task, '3d24de8b-b327-4c95-a469-392637497234', comment=user_comment)
#         # print(f'comment: {comment}')
#
#         preview = gazu.task.add_preview(task, comment, preview_file_path=kitsu_upload_path)
#         # print(f'preview: {preview}')
#
#         gazu.task.set_main_preview(preview['id'], 1)
#         mel.eval('confirmDialog -title "Confirm" -message "Publish Finished Successfully"')
