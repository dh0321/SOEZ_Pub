from pymel.core import *
from maya import mel
import math
s = 1  # start frame 렌더 시작 프레임 설정
e = 24  # end frame 렌더 끝내는 프레임 설정
nframes = e - s + 1
amount = 0
counter = 0
start_frame = s
for i in range(start_frame, e+1):
    currentTime(i)
    if i < s:
        continue
    mel.eval('renderWindowRender redoPreviousRender renderView;')
    counter += 1
    amount = int(math.floor(counter / nframes))

print('# Done')

# 현재 render_proto 코드는 아래 경로로 이미지 시퀀스를 생성함
# 경로: /home/rapa/maya/projects/default/images/tmp
# 대신 file_name_prefix 와 file_format 을 어디서 인식하는지 모르겠음...
# 일단 당장 작동을 하게 하는데, 해당 경로의 파일을 지정된 경로로 copy-paste 를 하면 이후 구동 단계까지 실행 가능하기는 함...