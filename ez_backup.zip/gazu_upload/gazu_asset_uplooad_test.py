import gazu
import os

gazu.client.set_host('http://192.168.3.117/api')
gazu.log_in('admin@netflixacademy.com', 'netflixacademy')


project_name = "SOEZ_TEST_2"
asset_name = 'test_jhw'
output_type_name = 'MOV'
output_type_short_name = 'MOV'
status_name = 'Todo'
# 아래 부분은 ui 상에서 유저가 입력하는 텍스트를 받게끔
user_comment = 'If seen on Kitsu, test successful 3 with todo stat'
# 아래 부분은 업로드할 파일을 지정해주는 경로
file_path = '/home/rapa/maya_test/cog_asset_v01/ren_mov/cog_v01.mov'

project = gazu.project.get_project_by_name(project_name)
print(f'project :{project}')
asset = gazu.asset.get_asset_by_name(project, asset_name)
print(f'asset: {asset}')

task_type = None
task_types = gazu.task.all_task_types_for_project(project)
print(f'task types: {task_types}')
for task_type in task_types:
    if task_type['name'] == 'Shading' and task_type['for_entity'] == asset['type']:
        task_type = task_type
        break
task = gazu.task.get_task_by_name(asset, task_type)
print(f'task: {task}')
working_file = gazu.files.new_working_file(task)
print(f'working_file: {working_file}')

# output_type = gazu.files.new_output_type(output_type_name, output_type_short_name)
#
# output_type = gazu.files.get_output_type_by_name("MOV")
# gazu.files.new_entity_output_file(asset, output_type, task_type,
#                                   'publish', working_file=working_file, revision=working_file['revision'])
#
# status = None
# all_status = gazu.task.all_task_statuses()
# print(f'all_status: {all_status}')
# for st in all_status:
#     if st.get('name') == status_name:
#         out = st
#         break
#     if st.get('short_name') == status_name:
#         out = st
#         break
#
# # 아래 코드에서 task 다음으로 오는 변수는 task_status 인데, str 도 받는다고는 되어있으나, 계속 에러 떠서 id 로 입력하니 받아짐.
# # 사용한 id 값은 all_status 에 들어있는 값을 참고하여 사용함
# comment = gazu.task.add_comment(task, '3d24de8b-b327-4c95-a469-392637497234', comment=user_comment)
# print(f'comment: {comment}')
# preview = gazu.task.add_preview(task, comment, preview_file_path=file_path)
# print(f'preview: {preview}')
#
# # 아래 코드들로 올라간 파일에 저장된 파일트리 값을 로컬에 생성해 줌. 여기를 통해서 마야씬파일, 퍼블리시파일, 영상 파일 3분류로 추가하면 될 듯
# if os.path.exists(working_file['path']) is False:
#     os.makedirs(working_file['path'])
# else:
#     pass
#
# # 아래 코드는 계속 에러가 남. 좀 더 메소드 내용 참고하고 연구해봐야 할 듯
# # gazu.task.set_main_preview(file_path)
