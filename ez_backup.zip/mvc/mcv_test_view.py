# -*- coding: utf-8 -*-
from PySide2.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QGridLayout,
    QWidget, QLineEdit, QPushButton, QLabel, QDialog, QFileDialog, QMessageBox, QScrollArea)
from PySide2.QtCore import Qt
from PySide2.QtGui import QGuiApplication, QScreen, QIcon, QKeySequence

import pickle

from login_ui_ver2_6 import Ui_MainWindow as login
from  main_ui_ver3_2 import Ui_MainWindow as main

from mcv_test_model import CustomTableModel as mt
from mcv_test_controller import MainControl as ct

class MainWindow(QMainWindow, main, login):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.setupUi(self)
        print(self)
        self._model = mt()
        self._con = ct()


        self.pushButton_publish.clicked.connect(self._con.kitsu_publish)
        self.commandLinkButton_go_kitsu.clicked.connect(self._con.go_kitsu)




#main
app = QApplication()

window = MainWindow()

window.show()

app.exec_()