# coding=utf-8

from PySide2.QtGui import QPixmap
from PySide2.QtCore import Qt, QAbstractTableModel, QModelIndex
import gazu
import os

gazu.client.set_host('http://192.168.3.117/api')
gazu.log_in('admin@netflixacademy.com', 'netflixacademy')

from pprint import pprint

class CustomTableModel(QAbstractTableModel):
    """
    task 선택하는 TableView의 모델
    """
    def __init__(self):

        QAbstractTableModel.__init__(self)
        self.project_name = "Avengers"
        self.asset_name = 'kitsu title fox'
        self.output_type_name = 'PNG'
        self.output_type_short_name = 'PNG'
        self.status_name = 'Todo'
        self.status_short_name = 'todo'
        self.user_comment = '뷰 테스트222'
        self.file_path = '/home/rapa/PycharmProjects/pythonProject/ui>py/free-beer-icon-1858-thumb.png'

    @property
    def project(self):
        return self.project_name

    @project.setter
    def project(self, value):
        self.project_name = value

    @property
    def asset(self):
        return self.asset_name

    @asset.setter
    def asset(self, value):
        self.asset_name = value

    @property
    def output_type(self):
        return self.output_type_name

    @output_type.setter
    def output_type(self, value):
        self.output_type_name = value

    @property
    def output_type_short(self):
        return self.output_type_short_name

    @output_type_short.setter
    def output_type_short(self, value):
        self.output_type_short_name = value

    @property
    def status(self):
        return self.status_name

    @status.setter
    def status(self, value):
        self.status_name = value

    @property
    def get_user_comment(self):
        return self.user_comment

    @get_user_comment.setter
    def get_user_comment(self, value):
        self.user_comment = value

    @property
    def get_file_path(self):
        return self.file_path

    @get_file_path.setter
    def get_file_path(self, value):
        self.file_path = value