# -*- coding: utf-8 -*-
from PySide2.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QGridLayout,
    QWidget, QLineEdit, QPushButton, QLabel, QDialog, QFileDialog, QMessageBox, QScrollArea)
from PySide2.QtCore import Qt
from PySide2.QtGui import QGuiApplication, QScreen, QIcon, QKeySequence

import gazu
import os

from mcv_test_model import CustomTableModel as mt

import pickle
from pprint import pprint
import webbrowser



class MainControl:
    gazu.client.set_host('http://192.168.3.117/api')
    gazu.log_in('admin@netflixacademy.com', 'netflixacademy')

    """
    프로그램의 메인윈도우를 정의하는 클래스이다.
    """
    def __init__(self):
        print("MainControl __init__")
        self.mt = mt()

    def go_kitsu(self):
        kitsu_productions = "http://192.168.3.117/productions/"
        webbrowser.open(kitsu_productions)
        print('go_kitsu')

    def kitsu_publish(self):
        self.project_name = self.mt.project_name
        self.asset_name = self.mt.asset_name
        self.output_type_name = self.mt.output_type_name
        self.output_type_short_name = self.mt.output_type_short_name
        self.status_name = self.mt.status_name
        self.status_short_name = self.mt.status_short_name
        self.user_comment = self.mt.user_comment
        self.file_path = self.mt.file_path

        self.project = gazu.project.get_project_by_name(self.project_name)
        # pprint(f'project :{self.project}')
        self.asset = gazu.asset.get_asset_by_name(self.project, self.asset_name)
        # pprint(f'asset: {self.asset}')
        self.task_type = None
        self.task_types = gazu.task.all_task_types_for_project(self.project)
        # pprint(f'task types: {self.task_types}')
        for task_type in self.task_types:
            if task_type['name'] == 'Shading' and task_type['for_entity'] == self.asset['type']:
                self.task_type = task_type
                # print("----------self.task_type = task_type---break를 사용하면 반복문을 중단하고 다음 문장으로 이동할 수 있습니다-------")
                break
        self.task = gazu.task.get_task_by_name(self.asset, self.task_type)
        # pprint(f'task: {self.task}')
        self.working_file = gazu.files.new_working_file(self.task)
        # pprint(f'working_file: {self.working_file}')
        self.output_type = gazu.files.new_output_type(self.output_type_name, self.output_type_short_name)
        #
        self.output_type = gazu.files.get_output_type_by_name(self.output_type_name)
        gazu.files.new_entity_output_file(self.asset, self.output_type, self.task_type, 'publish',
                                          working_file=self.working_file, revision=self.working_file['revision'])
        #
        status = None
        self.all_status = gazu.task.all_task_statuses()
        # pprint(f'all_status: {self.all_status}')
        for st in self.all_status:
            # pprint(self.status_name)
            if st.get('name') == self.status_name:
                # pprint(st)
                out = st
                # print(out)
                break
            if st.get('short_name') == self.status_name:
                out = st
                # print(out)
                break
        # pprint(self.task)
        self.task_status_id = self.task['task_status_id']
        self.comment = gazu.task.add_comment(self.task, self.task_status_id, comment=self.user_comment)
        # pprint(f'comment: {self.comment}')
        self.preview = gazu.task.add_preview(self.task, self.comment, preview_file_path=self.file_path)
        # pprint(f'preview: {self.preview}')

        if os.path.exists(self.working_file['path']) is False:
            os.makedirs(self.working_file['path'])
        else:
            pass
        # # gazu.task.set_main_preview(file_path)






m = MainControl()