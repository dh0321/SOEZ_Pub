from PySide2.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QGridLayout,
    QWidget, QLineEdit, QPushButton, QLabel, QDialog, QFileDialog, QMessageBox, QScrollArea)
from PySide2.QtCore import Qt
from PySide2.QtGui import QGuiApplication, QScreen, QIcon, QKeySequence
from scaled_in_grid_ver2_4 import Ui_MainWindow
import pickle



class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.setupUi(self)

        # tab_1
        self.pushButton_hdri_path.clicked.connect(self.hdri_path_clicked)
        self.pushButton_add_hdri_img.clicked.connect(self.add_hdri_img_clicked)

        # tab_2
        self.pushButton_import.clicked.connect(self.import_clicked)
        self.pushButton_hypershade.clicked.connect(self.hypershade_clicked)
        self.pushButton_render_setting.clicked.connect(self.render_setting_clicked)
        self.pushButton_render_view.clicked.connect(self.render_view_clicked)
        self.pushButton_save_file_path.clicked.connect(self.save_file_path_clicked)
        self.pushButton_render.clicked.connect(self.render_clicked)
        self.pushButton_create_vid.clicked.connect(self.create_vid_clicked)

        # tab_3
        self.pushButton_publish.clicked.connect(self.publish_clicked)
        self.pushButton_go_kitsu.clicked.connect(self.go_kitsu_clicked)

        # tab_4
        self.pushButton_asset_path.clicked.connect(self.asset_path_clicked)
        self.pushButton_add_asset.clicked.connect(self.add_asset_clicked)
        self.pushButton_import_asset.clicked.connect(self.import_asset_clicked)

    def login_clicked(self):
        print('login_kitsu')

    def hdri_path_clicked(self):
        print('hdri_path_clicked')

    def add_hdri_img_clicked(self):
        print('add_hdri_img_clicked')

    def import_clicked(self):
        print('import_clicked')

    def hypershade_clicked(self):
        print('open_hypershade_window')

    def render_setting_clicked(self):
        print('open_render_setting_window')

    def render_view_clicked(self):
        print('open_render_view_window')

    def save_file_path_clicked(self):
        print('open_save_file_path')

    def render_clicked(self):
        print('render')

    def create_vid_clicked(self):
        print('create_vid')

    def publish_clicked(self):
        print('publish_kitsu')

    def go_kitsu_clicked(self):
        print('open_kitsu_web')

    def asset_path_clicked(self):
        print('asset_path_clicked')

    def add_asset_clicked(self):
        print('add_asset_clicked')

    def import_asset_clicked(self):
        print('import_asset_clicked')


app = QApplication()

window = MainWindow()
window.show()

app.exec_()