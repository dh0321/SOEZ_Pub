# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'scaled_in_grid_ver2_5.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):

    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1791, 858)
        MainWindow.setMinimumSize(QSize(540, 770))
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setGeometry(QRect(9, 9, 480, 720))
        self.tabWidget.setMinimumSize(QSize(480, 720))
        self.tabWidget.setLayoutDirection(Qt.LeftToRight)
        self.tab_1_hdri = QWidget()
        self.tab_1_hdri.setObjectName(u"tab_1_hdri")
        self.gridLayout_4 = QGridLayout(self.tab_1_hdri)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.gridLayout_2 = QGridLayout()
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.label_change_hdri_img = QLabel(self.tab_1_hdri)
        self.label_change_hdri_img.setObjectName(u"label_change_hdri_img")
        self.label_change_hdri_img.setMinimumSize(QSize(430, 20))
        self.label_change_hdri_img.setLayoutDirection(Qt.LeftToRight)
        self.label_change_hdri_img.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_2.addWidget(self.label_change_hdri_img, 0, 0, 1, 2)

        self.listWidget_change_hdri_img = QListWidget(self.tab_1_hdri)
        self.listWidget_change_hdri_img.setObjectName(u"listWidget_change_hdri_img")
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.listWidget_change_hdri_img.sizePolicy().hasHeightForWidth())
        self.listWidget_change_hdri_img.setSizePolicy(sizePolicy)
        self.listWidget_change_hdri_img.setMinimumSize(QSize(160, 190))

        self.gridLayout_2.addWidget(self.listWidget_change_hdri_img, 1, 0, 1, 1)

        self.label_preview_hdri_img = QLabel(self.tab_1_hdri)
        self.label_preview_hdri_img.setObjectName(u"label_preview_hdri_img")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.label_preview_hdri_img.sizePolicy().hasHeightForWidth())
        self.label_preview_hdri_img.setSizePolicy(sizePolicy1)
        self.label_preview_hdri_img.setMinimumSize(QSize(250, 190))

        self.gridLayout_2.addWidget(self.label_preview_hdri_img, 1, 1, 1, 1)

        self.pushButton_add_hdri_img = QPushButton(self.tab_1_hdri)
        self.pushButton_add_hdri_img.setObjectName(u"pushButton_add_hdri_img")
        self.pushButton_add_hdri_img.setMinimumSize(QSize(430, 100))

        self.gridLayout_2.addWidget(self.pushButton_add_hdri_img, 6, 0, 1, 2)

        self.verticalSpacer = QSpacerItem(428, 168, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.gridLayout_2.addItem(self.verticalSpacer, 7, 0, 1, 2)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label_hdri_path = QLabel(self.tab_1_hdri)
        self.label_hdri_path.setObjectName(u"label_hdri_path")
        self.label_hdri_path.setMinimumSize(QSize(65, 30))

        self.horizontalLayout.addWidget(self.label_hdri_path)

        self.lineEdit_hdri_path = QLineEdit(self.tab_1_hdri)
        self.lineEdit_hdri_path.setObjectName(u"lineEdit_hdri_path")
        sizePolicy2 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.lineEdit_hdri_path.sizePolicy().hasHeightForWidth())
        self.lineEdit_hdri_path.setSizePolicy(sizePolicy2)
        self.lineEdit_hdri_path.setMinimumSize(QSize(260, 30))

        self.horizontalLayout.addWidget(self.lineEdit_hdri_path)

        self.pushButton_hdri_path = QPushButton(self.tab_1_hdri)
        self.pushButton_hdri_path.setObjectName(u"pushButton_hdri_path")
        sizePolicy3 = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.pushButton_hdri_path.sizePolicy().hasHeightForWidth())
        self.pushButton_hdri_path.setSizePolicy(sizePolicy3)
        self.pushButton_hdri_path.setMinimumSize(QSize(90, 30))

        self.horizontalLayout.addWidget(self.pushButton_hdri_path)


        self.gridLayout_2.addLayout(self.horizontalLayout, 5, 0, 1, 2)

        self.line_hdri = QFrame(self.tab_1_hdri)
        self.line_hdri.setObjectName(u"line_hdri")
        self.line_hdri.setMinimumSize(QSize(430, 16))
        self.line_hdri.setFrameShape(QFrame.HLine)
        self.line_hdri.setFrameShadow(QFrame.Sunken)

        self.gridLayout_2.addWidget(self.line_hdri, 2, 0, 1, 2)

        self.label_add_hdri_img = QLabel(self.tab_1_hdri)
        self.label_add_hdri_img.setObjectName(u"label_add_hdri_img")
        self.label_add_hdri_img.setMinimumSize(QSize(430, 20))
        self.label_add_hdri_img.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_2.addWidget(self.label_add_hdri_img, 3, 0, 1, 2)

        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.label_hdri_project = QLabel(self.tab_1_hdri)
        self.label_hdri_project.setObjectName(u"label_hdri_project")
        self.label_hdri_project.setMinimumSize(QSize(130, 20))
        self.label_hdri_project.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout.addWidget(self.label_hdri_project, 0, 0, 1, 1)

        self.label_hdri_asset = QLabel(self.tab_1_hdri)
        self.label_hdri_asset.setObjectName(u"label_hdri_asset")
        self.label_hdri_asset.setMinimumSize(QSize(130, 20))
        self.label_hdri_asset.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout.addWidget(self.label_hdri_asset, 0, 1, 1, 1)

        self.label_hdri_task = QLabel(self.tab_1_hdri)
        self.label_hdri_task.setObjectName(u"label_hdri_task")
        self.label_hdri_task.setMinimumSize(QSize(130, 20))
        self.label_hdri_task.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout.addWidget(self.label_hdri_task, 0, 2, 1, 1)

        self.comboBox_hdri_project = QComboBox(self.tab_1_hdri)
        self.comboBox_hdri_project.setObjectName(u"comboBox_hdri_project")
        sizePolicy.setHeightForWidth(self.comboBox_hdri_project.sizePolicy().hasHeightForWidth())
        self.comboBox_hdri_project.setSizePolicy(sizePolicy)
        self.comboBox_hdri_project.setMinimumSize(QSize(130, 30))

        self.gridLayout.addWidget(self.comboBox_hdri_project, 1, 0, 1, 1)

        self.comboBox_hdri_asset = QComboBox(self.tab_1_hdri)
        self.comboBox_hdri_asset.setObjectName(u"comboBox_hdri_asset")
        sizePolicy.setHeightForWidth(self.comboBox_hdri_asset.sizePolicy().hasHeightForWidth())
        self.comboBox_hdri_asset.setSizePolicy(sizePolicy)
        self.comboBox_hdri_asset.setMinimumSize(QSize(130, 30))

        self.gridLayout.addWidget(self.comboBox_hdri_asset, 1, 1, 1, 1)

        self.comboBox_hdri_task = QComboBox(self.tab_1_hdri)
        self.comboBox_hdri_task.setObjectName(u"comboBox_hdri_task")
        sizePolicy.setHeightForWidth(self.comboBox_hdri_task.sizePolicy().hasHeightForWidth())
        self.comboBox_hdri_task.setSizePolicy(sizePolicy)
        self.comboBox_hdri_task.setMinimumSize(QSize(130, 30))

        self.gridLayout.addWidget(self.comboBox_hdri_task, 1, 2, 1, 1)


        self.gridLayout_2.addLayout(self.gridLayout, 4, 0, 1, 2)


        self.gridLayout_4.addLayout(self.gridLayout_2, 0, 0, 1, 1)

        self.tabWidget.addTab(self.tab_1_hdri, "")
        self.tab_2_render = QWidget()
        self.tab_2_render.setObjectName(u"tab_2_render")
        self.gridLayout_9 = QGridLayout(self.tab_2_render)
        self.gridLayout_9.setObjectName(u"gridLayout_9")
        self.tabWidget.addTab(self.tab_2_render, "")
        self.tab_3_kitsu = QWidget()
        self.tab_3_kitsu.setObjectName(u"tab_3_kitsu")
        self.gridLayout_13 = QGridLayout(self.tab_3_kitsu)
        self.gridLayout_13.setObjectName(u"gridLayout_13")
        self.gridLayout_12 = QGridLayout()
        self.gridLayout_12.setObjectName(u"gridLayout_12")
        self.gridLayout_10 = QGridLayout()
        self.gridLayout_10.setObjectName(u"gridLayout_10")
        self.label_selected_vid_name = QLabel(self.tab_3_kitsu)
        self.label_selected_vid_name.setObjectName(u"label_selected_vid_name")
        sizePolicy2.setHeightForWidth(self.label_selected_vid_name.sizePolicy().hasHeightForWidth())
        self.label_selected_vid_name.setSizePolicy(sizePolicy2)
        self.label_selected_vid_name.setMinimumSize(QSize(370, 20))

        self.gridLayout_10.addWidget(self.label_selected_vid_name, 1, 1, 1, 1)

        self.label_user = QLabel(self.tab_3_kitsu)
        self.label_user.setObjectName(u"label_user")
        sizePolicy.setHeightForWidth(self.label_user.sizePolicy().hasHeightForWidth())
        self.label_user.setSizePolicy(sizePolicy)
        self.label_user.setMinimumSize(QSize(50, 20))

        self.gridLayout_10.addWidget(self.label_user, 0, 0, 1, 1)

        self.label_video = QLabel(self.tab_3_kitsu)
        self.label_video.setObjectName(u"label_video")
        sizePolicy.setHeightForWidth(self.label_video.sizePolicy().hasHeightForWidth())
        self.label_video.setSizePolicy(sizePolicy)
        self.label_video.setMinimumSize(QSize(50, 20))

        self.gridLayout_10.addWidget(self.label_video, 1, 0, 1, 1)

        self.label_user_name = QLabel(self.tab_3_kitsu)
        self.label_user_name.setObjectName(u"label_user_name")
        sizePolicy2.setHeightForWidth(self.label_user_name.sizePolicy().hasHeightForWidth())
        self.label_user_name.setSizePolicy(sizePolicy2)
        self.label_user_name.setMinimumSize(QSize(370, 20))

        self.gridLayout_10.addWidget(self.label_user_name, 0, 1, 1, 1)

        self.pushButton = QPushButton(self.tab_3_kitsu)
        self.pushButton.setObjectName(u"pushButton")
        sizePolicy4 = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Expanding)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.pushButton.sizePolicy().hasHeightForWidth())
        self.pushButton.setSizePolicy(sizePolicy4)

        self.gridLayout_10.addWidget(self.pushButton, 0, 2, 2, 1)


        self.gridLayout_12.addLayout(self.gridLayout_10, 0, 0, 1, 1)

        self.label_preview_vid = QLabel(self.tab_3_kitsu)
        self.label_preview_vid.setObjectName(u"label_preview_vid")
        self.label_preview_vid.setMinimumSize(QSize(430, 180))

        self.gridLayout_12.addWidget(self.label_preview_vid, 1, 0, 1, 1)

        self.gridLayout_11 = QGridLayout()
        self.gridLayout_11.setObjectName(u"gridLayout_11")
        self.label_vid_project = QLabel(self.tab_3_kitsu)
        self.label_vid_project.setObjectName(u"label_vid_project")
        self.label_vid_project.setMinimumSize(QSize(130, 20))
        self.label_vid_project.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_11.addWidget(self.label_vid_project, 0, 0, 1, 1)

        self.label_vid_task = QLabel(self.tab_3_kitsu)
        self.label_vid_task.setObjectName(u"label_vid_task")
        self.label_vid_task.setMinimumSize(QSize(130, 20))
        self.label_vid_task.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_11.addWidget(self.label_vid_task, 0, 1, 1, 1)

        self.label_vid_asset = QLabel(self.tab_3_kitsu)
        self.label_vid_asset.setObjectName(u"label_vid_asset")
        self.label_vid_asset.setMinimumSize(QSize(130, 20))
        self.label_vid_asset.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_11.addWidget(self.label_vid_asset, 0, 2, 1, 1)

        self.comboBox_vid_project = QComboBox(self.tab_3_kitsu)
        self.comboBox_vid_project.setObjectName(u"comboBox_vid_project")
        sizePolicy.setHeightForWidth(self.comboBox_vid_project.sizePolicy().hasHeightForWidth())
        self.comboBox_vid_project.setSizePolicy(sizePolicy)
        self.comboBox_vid_project.setMinimumSize(QSize(130, 30))

        self.gridLayout_11.addWidget(self.comboBox_vid_project, 1, 0, 1, 1)

        self.comboBox_vid_asset = QComboBox(self.tab_3_kitsu)
        self.comboBox_vid_asset.setObjectName(u"comboBox_vid_asset")
        sizePolicy.setHeightForWidth(self.comboBox_vid_asset.sizePolicy().hasHeightForWidth())
        self.comboBox_vid_asset.setSizePolicy(sizePolicy)
        self.comboBox_vid_asset.setMinimumSize(QSize(130, 30))

        self.gridLayout_11.addWidget(self.comboBox_vid_asset, 1, 1, 1, 1)

        self.comboBox_vid_task = QComboBox(self.tab_3_kitsu)
        self.comboBox_vid_task.setObjectName(u"comboBox_vid_task")
        sizePolicy.setHeightForWidth(self.comboBox_vid_task.sizePolicy().hasHeightForWidth())
        self.comboBox_vid_task.setSizePolicy(sizePolicy)
        self.comboBox_vid_task.setMinimumSize(QSize(130, 30))

        self.gridLayout_11.addWidget(self.comboBox_vid_task, 1, 2, 1, 1)


        self.gridLayout_12.addLayout(self.gridLayout_11, 2, 0, 1, 1)

        self.label_post_comment = QLabel(self.tab_3_kitsu)
        self.label_post_comment.setObjectName(u"label_post_comment")
        self.label_post_comment.setMinimumSize(QSize(430, 20))
        self.label_post_comment.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_12.addWidget(self.label_post_comment, 3, 0, 1, 1)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.textEdit_leave_a_comment = QTextEdit(self.tab_3_kitsu)
        self.textEdit_leave_a_comment.setObjectName(u"textEdit_leave_a_comment")
        self.textEdit_leave_a_comment.setMinimumSize(QSize(280, 80))

        self.horizontalLayout_6.addWidget(self.textEdit_leave_a_comment)

        self.pushButton_publish = QPushButton(self.tab_3_kitsu)
        self.pushButton_publish.setObjectName(u"pushButton_publish")
        sizePolicy.setHeightForWidth(self.pushButton_publish.sizePolicy().hasHeightForWidth())
        self.pushButton_publish.setSizePolicy(sizePolicy)
        self.pushButton_publish.setMinimumSize(QSize(130, 80))

        self.horizontalLayout_6.addWidget(self.pushButton_publish)


        self.gridLayout_12.addLayout(self.horizontalLayout_6, 4, 0, 1, 1)

        self.progressBar_publish = QProgressBar(self.tab_3_kitsu)
        self.progressBar_publish.setObjectName(u"progressBar_publish")
        sizePolicy.setHeightForWidth(self.progressBar_publish.sizePolicy().hasHeightForWidth())
        self.progressBar_publish.setSizePolicy(sizePolicy)
        self.progressBar_publish.setMinimumSize(QSize(430, 20))
        self.progressBar_publish.setMaximumSize(QSize(16777215, 200))
        self.progressBar_publish.setValue(24)

        self.gridLayout_12.addWidget(self.progressBar_publish, 5, 0, 1, 1)

        self.pushButton_go_kitsu = QPushButton(self.tab_3_kitsu)
        self.pushButton_go_kitsu.setObjectName(u"pushButton_go_kitsu")
        self.pushButton_go_kitsu.setMinimumSize(QSize(430, 100))

        self.gridLayout_12.addWidget(self.pushButton_go_kitsu, 6, 0, 1, 1)

        self.verticalSpacer_3 = QSpacerItem(428, 78, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_3, 7, 0, 1, 1)


        self.gridLayout_13.addLayout(self.gridLayout_12, 0, 0, 1, 1)

        self.tabWidget.addTab(self.tab_3_kitsu, "")
        self.tab_4_asset_lib = QWidget()
        self.tab_4_asset_lib.setObjectName(u"tab_4_asset_lib")
        self.gridLayout_16 = QGridLayout(self.tab_4_asset_lib)
        self.gridLayout_16.setObjectName(u"gridLayout_16")
        self.gridLayout_15 = QGridLayout()
        self.gridLayout_15.setObjectName(u"gridLayout_15")
        self.verticalScrollBar_asset_lib = QScrollBar(self.tab_4_asset_lib)
        self.verticalScrollBar_asset_lib.setObjectName(u"verticalScrollBar_asset_lib")
        sizePolicy.setHeightForWidth(self.verticalScrollBar_asset_lib.sizePolicy().hasHeightForWidth())
        self.verticalScrollBar_asset_lib.setSizePolicy(sizePolicy)
        self.verticalScrollBar_asset_lib.setMinimumSize(QSize(16, 200))
        self.verticalScrollBar_asset_lib.setOrientation(Qt.Vertical)

        self.gridLayout_15.addWidget(self.verticalScrollBar_asset_lib, 1, 1, 1, 1)

        self.verticalSpacer_4 = QSpacerItem(428, 118, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.gridLayout_15.addItem(self.verticalSpacer_4, 7, 0, 1, 2)

        self.scrollArea_asset_lib = QScrollArea(self.tab_4_asset_lib)
        self.scrollArea_asset_lib.setObjectName(u"scrollArea_asset_lib")
        self.scrollArea_asset_lib.setMinimumSize(QSize(400, 200))
        self.scrollArea_asset_lib.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 432, 198))
        self.scrollArea_asset_lib.setWidget(self.scrollAreaWidgetContents)

        self.gridLayout_15.addWidget(self.scrollArea_asset_lib, 1, 0, 1, 1)

        self.label_asset_lib = QLabel(self.tab_4_asset_lib)
        self.label_asset_lib.setObjectName(u"label_asset_lib")
        self.label_asset_lib.setMinimumSize(QSize(430, 20))
        self.label_asset_lib.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_15.addWidget(self.label_asset_lib, 0, 0, 1, 2)

        self.label_add_asset_img = QLabel(self.tab_4_asset_lib)
        self.label_add_asset_img.setObjectName(u"label_add_asset_img")
        self.label_add_asset_img.setMinimumSize(QSize(430, 20))
        self.label_add_asset_img.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_15.addWidget(self.label_add_asset_img, 3, 0, 1, 2)

        self.line_asset_lib = QFrame(self.tab_4_asset_lib)
        self.line_asset_lib.setObjectName(u"line_asset_lib")
        self.line_asset_lib.setMinimumSize(QSize(430, 16))
        self.line_asset_lib.setFrameShape(QFrame.HLine)
        self.line_asset_lib.setFrameShadow(QFrame.Sunken)

        self.gridLayout_15.addWidget(self.line_asset_lib, 2, 0, 1, 2)

        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.label_asset_path = QLabel(self.tab_4_asset_lib)
        self.label_asset_path.setObjectName(u"label_asset_path")
        self.label_asset_path.setMinimumSize(QSize(65, 30))

        self.horizontalLayout_7.addWidget(self.label_asset_path)

        self.lineEdit_asset_path = QLineEdit(self.tab_4_asset_lib)
        self.lineEdit_asset_path.setObjectName(u"lineEdit_asset_path")
        sizePolicy2.setHeightForWidth(self.lineEdit_asset_path.sizePolicy().hasHeightForWidth())
        self.lineEdit_asset_path.setSizePolicy(sizePolicy2)
        self.lineEdit_asset_path.setMinimumSize(QSize(260, 30))

        self.horizontalLayout_7.addWidget(self.lineEdit_asset_path)

        self.pushButton_asset_path = QPushButton(self.tab_4_asset_lib)
        self.pushButton_asset_path.setObjectName(u"pushButton_asset_path")
        sizePolicy.setHeightForWidth(self.pushButton_asset_path.sizePolicy().hasHeightForWidth())
        self.pushButton_asset_path.setSizePolicy(sizePolicy)
        self.pushButton_asset_path.setMinimumSize(QSize(90, 30))

        self.horizontalLayout_7.addWidget(self.pushButton_asset_path)


        self.gridLayout_15.addLayout(self.horizontalLayout_7, 5, 0, 1, 2)

        self.gridLayout_14 = QGridLayout()
        self.gridLayout_14.setObjectName(u"gridLayout_14")
        self.label_asset_lib_project = QLabel(self.tab_4_asset_lib)
        self.label_asset_lib_project.setObjectName(u"label_asset_lib_project")
        self.label_asset_lib_project.setMinimumSize(QSize(130, 20))
        self.label_asset_lib_project.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_14.addWidget(self.label_asset_lib_project, 0, 0, 1, 1)

        self.label_asset_lib_asset = QLabel(self.tab_4_asset_lib)
        self.label_asset_lib_asset.setObjectName(u"label_asset_lib_asset")
        self.label_asset_lib_asset.setMinimumSize(QSize(130, 20))
        self.label_asset_lib_asset.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_14.addWidget(self.label_asset_lib_asset, 0, 1, 1, 1)

        self.label_asset_lib_task = QLabel(self.tab_4_asset_lib)
        self.label_asset_lib_task.setObjectName(u"label_asset_lib_task")
        self.label_asset_lib_task.setMinimumSize(QSize(130, 20))
        self.label_asset_lib_task.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_14.addWidget(self.label_asset_lib_task, 0, 2, 1, 1)

        self.comboBox_asset_lib_project = QComboBox(self.tab_4_asset_lib)
        self.comboBox_asset_lib_project.setObjectName(u"comboBox_asset_lib_project")
        sizePolicy.setHeightForWidth(self.comboBox_asset_lib_project.sizePolicy().hasHeightForWidth())
        self.comboBox_asset_lib_project.setSizePolicy(sizePolicy)
        self.comboBox_asset_lib_project.setMinimumSize(QSize(130, 30))

        self.gridLayout_14.addWidget(self.comboBox_asset_lib_project, 1, 0, 1, 1)

        self.comboBox_asset_lib_asset = QComboBox(self.tab_4_asset_lib)
        self.comboBox_asset_lib_asset.setObjectName(u"comboBox_asset_lib_asset")
        sizePolicy.setHeightForWidth(self.comboBox_asset_lib_asset.sizePolicy().hasHeightForWidth())
        self.comboBox_asset_lib_asset.setSizePolicy(sizePolicy)
        self.comboBox_asset_lib_asset.setMinimumSize(QSize(130, 30))

        self.gridLayout_14.addWidget(self.comboBox_asset_lib_asset, 1, 1, 1, 1)

        self.comboBox_asset_lib_task = QComboBox(self.tab_4_asset_lib)
        self.comboBox_asset_lib_task.setObjectName(u"comboBox_asset_lib_task")
        sizePolicy.setHeightForWidth(self.comboBox_asset_lib_task.sizePolicy().hasHeightForWidth())
        self.comboBox_asset_lib_task.setSizePolicy(sizePolicy)
        self.comboBox_asset_lib_task.setMinimumSize(QSize(130, 30))

        self.gridLayout_14.addWidget(self.comboBox_asset_lib_task, 1, 2, 1, 1)


        self.gridLayout_15.addLayout(self.gridLayout_14, 4, 0, 1, 2)

        self.horizontalLayout_9 = QHBoxLayout()
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.pushButton_add_asset = QPushButton(self.tab_4_asset_lib)
        self.pushButton_add_asset.setObjectName(u"pushButton_add_asset")
        sizePolicy.setHeightForWidth(self.pushButton_add_asset.sizePolicy().hasHeightForWidth())
        self.pushButton_add_asset.setSizePolicy(sizePolicy)
        self.pushButton_add_asset.setMinimumSize(QSize(200, 100))

        self.horizontalLayout_9.addWidget(self.pushButton_add_asset)

        self.pushButton_import_asset = QPushButton(self.tab_4_asset_lib)
        self.pushButton_import_asset.setObjectName(u"pushButton_import_asset")
        sizePolicy.setHeightForWidth(self.pushButton_import_asset.sizePolicy().hasHeightForWidth())
        self.pushButton_import_asset.setSizePolicy(sizePolicy)
        self.pushButton_import_asset.setMinimumSize(QSize(200, 100))

        self.horizontalLayout_9.addWidget(self.pushButton_import_asset)


        self.gridLayout_15.addLayout(self.horizontalLayout_9, 6, 0, 1, 2)


        self.gridLayout_16.addLayout(self.gridLayout_15, 0, 0, 1, 1)

        self.tabWidget.addTab(self.tab_4_asset_lib, "")
        self.groupBox_3 = QGroupBox(self.centralwidget)
        self.groupBox_3.setObjectName(u"groupBox_3")
        self.groupBox_3.setGeometry(QRect(510, 120, 601, 331))
        self.layoutWidget = QWidget(self.groupBox_3)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(10, 10, 351, 166))
        self.gridLayout_18 = QGridLayout(self.layoutWidget)
        self.gridLayout_18.setObjectName(u"gridLayout_18")
        self.gridLayout_18.setContentsMargins(0, 0, 0, 0)
        self.label_mesh = QLabel(self.layoutWidget)
        self.label_mesh.setObjectName(u"label_mesh")
        self.label_mesh.setMinimumSize(QSize(0, 20))
        self.label_mesh.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_18.addWidget(self.label_mesh, 0, 0, 1, 2)

        self.label_skydome = QLabel(self.layoutWidget)
        self.label_skydome.setObjectName(u"label_skydome")
        self.label_skydome.setMinimumSize(QSize(0, 20))
        self.label_skydome.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_18.addWidget(self.label_skydome, 0, 2, 1, 2)

        self.label_mesh_start_frame = QLabel(self.layoutWidget)
        self.label_mesh_start_frame.setObjectName(u"label_mesh_start_frame")
        sizePolicy.setHeightForWidth(self.label_mesh_start_frame.sizePolicy().hasHeightForWidth())
        self.label_mesh_start_frame.setSizePolicy(sizePolicy)
        self.label_mesh_start_frame.setMinimumSize(QSize(90, 30))

        self.gridLayout_18.addWidget(self.label_mesh_start_frame, 1, 0, 1, 1)

        self.lineEdit_mesh_start_frame = QLineEdit(self.layoutWidget)
        self.lineEdit_mesh_start_frame.setObjectName(u"lineEdit_mesh_start_frame")
        sizePolicy.setHeightForWidth(self.lineEdit_mesh_start_frame.sizePolicy().hasHeightForWidth())
        self.lineEdit_mesh_start_frame.setSizePolicy(sizePolicy)
        self.lineEdit_mesh_start_frame.setMinimumSize(QSize(50, 30))


        self.gridLayout_18.addWidget(self.lineEdit_mesh_start_frame, 1, 1, 1, 1)

        self.label_skydome_start_frame = QLabel(self.layoutWidget)
        self.label_skydome_start_frame.setObjectName(u"label_skydome_start_frame")
        sizePolicy.setHeightForWidth(self.label_skydome_start_frame.sizePolicy().hasHeightForWidth())
        self.label_skydome_start_frame.setSizePolicy(sizePolicy)
        self.label_skydome_start_frame.setMinimumSize(QSize(90, 30))

        self.gridLayout_18.addWidget(self.label_skydome_start_frame, 1, 2, 1, 1)

        self.lineEdit_skydome_start_frame = QLineEdit(self.layoutWidget)
        self.lineEdit_skydome_start_frame.setObjectName(u"lineEdit_skydome_start_frame")
        sizePolicy.setHeightForWidth(self.lineEdit_skydome_start_frame.sizePolicy().hasHeightForWidth())
        self.lineEdit_skydome_start_frame.setSizePolicy(sizePolicy)
        self.lineEdit_skydome_start_frame.setMinimumSize(QSize(50, 30))

        self.gridLayout_18.addWidget(self.lineEdit_skydome_start_frame, 1, 3, 1, 1)

        self.label_mesh_end_frame = QLabel(self.layoutWidget)
        self.label_mesh_end_frame.setObjectName(u"label_mesh_end_frame")
        sizePolicy.setHeightForWidth(self.label_mesh_end_frame.sizePolicy().hasHeightForWidth())
        self.label_mesh_end_frame.setSizePolicy(sizePolicy)
        self.label_mesh_end_frame.setMinimumSize(QSize(90, 30))

        self.gridLayout_18.addWidget(self.label_mesh_end_frame, 2, 0, 1, 1)

        self.lineEdit_mesh_end_frame = QLineEdit(self.layoutWidget)
        self.lineEdit_mesh_end_frame.setObjectName(u"lineEdit_mesh_end_frame")
        sizePolicy.setHeightForWidth(self.lineEdit_mesh_end_frame.sizePolicy().hasHeightForWidth())
        self.lineEdit_mesh_end_frame.setSizePolicy(sizePolicy)
        self.lineEdit_mesh_end_frame.setMinimumSize(QSize(50, 30))

        self.gridLayout_18.addWidget(self.lineEdit_mesh_end_frame, 2, 1, 1, 1)

        self.label_skydome_end_frame = QLabel(self.layoutWidget)
        self.label_skydome_end_frame.setObjectName(u"label_skydome_end_frame")
        sizePolicy.setHeightForWidth(self.label_skydome_end_frame.sizePolicy().hasHeightForWidth())
        self.label_skydome_end_frame.setSizePolicy(sizePolicy)
        self.label_skydome_end_frame.setMinimumSize(QSize(90, 30))

        self.gridLayout_18.addWidget(self.label_skydome_end_frame, 2, 2, 1, 1)

        self.lineEdit_skydome_end_frame = QLineEdit(self.layoutWidget)
        self.lineEdit_skydome_end_frame.setObjectName(u"lineEdit_skydome_end_frame")
        sizePolicy.setHeightForWidth(self.lineEdit_skydome_end_frame.sizePolicy().hasHeightForWidth())
        self.lineEdit_skydome_end_frame.setSizePolicy(sizePolicy)
        self.lineEdit_skydome_end_frame.setMinimumSize(QSize(50, 30))

        self.gridLayout_18.addWidget(self.lineEdit_skydome_end_frame, 2, 3, 1, 1)

        self.label_mesh_start_rotate = QLabel(self.layoutWidget)
        self.label_mesh_start_rotate.setObjectName(u"label_mesh_start_rotate")
        sizePolicy.setHeightForWidth(self.label_mesh_start_rotate.sizePolicy().hasHeightForWidth())
        self.label_mesh_start_rotate.setSizePolicy(sizePolicy)
        self.label_mesh_start_rotate.setMinimumSize(QSize(90, 30))

        self.gridLayout_18.addWidget(self.label_mesh_start_rotate, 3, 0, 1, 1)

        self.lineEdit_mesh_start_rotate = QLineEdit(self.layoutWidget)
        self.lineEdit_mesh_start_rotate.setObjectName(u"lineEdit_mesh_start_rotate")
        sizePolicy.setHeightForWidth(self.lineEdit_mesh_start_rotate.sizePolicy().hasHeightForWidth())
        self.lineEdit_mesh_start_rotate.setSizePolicy(sizePolicy)
        self.lineEdit_mesh_start_rotate.setMinimumSize(QSize(50, 30))
        self.lineEdit_mesh_start_rotate.setLayoutDirection(Qt.LeftToRight)
        self.lineEdit_mesh_start_rotate.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.gridLayout_18.addWidget(self.lineEdit_mesh_start_rotate, 3, 1, 1, 1)

        self.label_skydome_start_rotate = QLabel(self.layoutWidget)
        self.label_skydome_start_rotate.setObjectName(u"label_skydome_start_rotate")
        sizePolicy.setHeightForWidth(self.label_skydome_start_rotate.sizePolicy().hasHeightForWidth())
        self.label_skydome_start_rotate.setSizePolicy(sizePolicy)
        self.label_skydome_start_rotate.setMinimumSize(QSize(90, 30))

        self.gridLayout_18.addWidget(self.label_skydome_start_rotate, 3, 2, 1, 1)

        self.lineEdit_skydome_start_rotate = QLineEdit(self.layoutWidget)
        self.lineEdit_skydome_start_rotate.setObjectName(u"lineEdit_skydome_start_rotate")
        sizePolicy.setHeightForWidth(self.lineEdit_skydome_start_rotate.sizePolicy().hasHeightForWidth())
        self.lineEdit_skydome_start_rotate.setSizePolicy(sizePolicy)
        self.lineEdit_skydome_start_rotate.setMinimumSize(QSize(50, 30))
        self.lineEdit_skydome_start_rotate.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.gridLayout_18.addWidget(self.lineEdit_skydome_start_rotate, 3, 3, 1, 1)

        self.label_mesh_end_rotate = QLabel(self.layoutWidget)
        self.label_mesh_end_rotate.setObjectName(u"label_mesh_end_rotate")
        sizePolicy.setHeightForWidth(self.label_mesh_end_rotate.sizePolicy().hasHeightForWidth())
        self.label_mesh_end_rotate.setSizePolicy(sizePolicy)
        self.label_mesh_end_rotate.setMinimumSize(QSize(90, 30))

        self.gridLayout_18.addWidget(self.label_mesh_end_rotate, 4, 0, 1, 1)

        self.lineEdit_mesh_end_rotate = QLineEdit(self.layoutWidget)
        self.lineEdit_mesh_end_rotate.setObjectName(u"lineEdit_mesh_end_rotate")
        sizePolicy.setHeightForWidth(self.lineEdit_mesh_end_rotate.sizePolicy().hasHeightForWidth())
        self.lineEdit_mesh_end_rotate.setSizePolicy(sizePolicy)
        self.lineEdit_mesh_end_rotate.setMinimumSize(QSize(50, 30))
        self.lineEdit_mesh_end_rotate.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.gridLayout_18.addWidget(self.lineEdit_mesh_end_rotate, 4, 1, 1, 1)

        self.label_skydome_end_rotate = QLabel(self.layoutWidget)
        self.label_skydome_end_rotate.setObjectName(u"label_skydome_end_rotate")
        sizePolicy.setHeightForWidth(self.label_skydome_end_rotate.sizePolicy().hasHeightForWidth())
        self.label_skydome_end_rotate.setSizePolicy(sizePolicy)
        self.label_skydome_end_rotate.setMinimumSize(QSize(90, 30))

        self.gridLayout_18.addWidget(self.label_skydome_end_rotate, 4, 2, 1, 1)

        self.lineEdit_skydome_end_rotate = QLineEdit(self.layoutWidget)
        self.lineEdit_skydome_end_rotate.setObjectName(u"lineEdit_skydome_end_rotate")
        sizePolicy.setHeightForWidth(self.lineEdit_skydome_end_rotate.sizePolicy().hasHeightForWidth())
        self.lineEdit_skydome_end_rotate.setSizePolicy(sizePolicy)
        self.lineEdit_skydome_end_rotate.setMinimumSize(QSize(50, 30))
        self.lineEdit_skydome_end_rotate.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.gridLayout_18.addWidget(self.lineEdit_skydome_end_rotate, 4, 3, 1, 1)

        self.layoutWidget_8 = QWidget(self.groupBox_3)
        self.layoutWidget_8.setObjectName(u"layoutWidget_8")
        self.layoutWidget_8.setGeometry(QRect(10, 190, 351, 131))
        self.horizontalLayout_3 = QHBoxLayout(self.layoutWidget_8)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.pushButton_hypershade = QPushButton(self.layoutWidget_8)
        self.pushButton_hypershade.setObjectName(u"pushButton_hypershade")
        sizePolicy.setHeightForWidth(self.pushButton_hypershade.sizePolicy().hasHeightForWidth())
        self.pushButton_hypershade.setSizePolicy(sizePolicy)
        self.pushButton_hypershade.setMinimumSize(QSize(100, 100))

        self.horizontalLayout_3.addWidget(self.pushButton_hypershade)

        self.pushButton_render_setting = QPushButton(self.layoutWidget_8)
        self.pushButton_render_setting.setObjectName(u"pushButton_render_setting")
        sizePolicy.setHeightForWidth(self.pushButton_render_setting.sizePolicy().hasHeightForWidth())
        self.pushButton_render_setting.setSizePolicy(sizePolicy)
        self.pushButton_render_setting.setMinimumSize(QSize(100, 100))

        self.horizontalLayout_3.addWidget(self.pushButton_render_setting)

        self.pushButton_render_view = QPushButton(self.layoutWidget_8)
        self.pushButton_render_view.setObjectName(u"pushButton_render_view")
        sizePolicy.setHeightForWidth(self.pushButton_render_view.sizePolicy().hasHeightForWidth())
        self.pushButton_render_view.setSizePolicy(sizePolicy)
        self.pushButton_render_view.setMinimumSize(QSize(100, 100))

        self.horizontalLayout_3.addWidget(self.pushButton_render_view)

        self.layoutWidget1 = QWidget(self.groupBox_3)
        self.layoutWidget1.setObjectName(u"layoutWidget1")
        self.layoutWidget1.setGeometry(QRect(370, 10, 221, 310))
        self.gridLayout_5 = QGridLayout(self.layoutWidget1)
        self.gridLayout_5.setObjectName(u"gridLayout_5")
        self.gridLayout_5.setContentsMargins(0, 0, 0, 0)
        self.label_img_name = QLabel(self.layoutWidget1)
        self.label_img_name.setObjectName(u"label_img_name")
        sizePolicy.setHeightForWidth(self.label_img_name.sizePolicy().hasHeightForWidth())
        self.label_img_name.setSizePolicy(sizePolicy)
        self.label_img_name.setMinimumSize(QSize(0, 0))

        self.gridLayout_5.addWidget(self.label_img_name, 4, 0, 1, 2)

        self.lineEidt_video_path = QLineEdit(self.layoutWidget1)
        self.lineEidt_video_path.setObjectName(u"lineEidt_video_path")
        sizePolicy.setHeightForWidth(self.lineEidt_video_path.sizePolicy().hasHeightForWidth())
        self.lineEidt_video_path.setSizePolicy(sizePolicy)
        self.lineEidt_video_path.setMinimumSize(QSize(50, 30))

        self.gridLayout_5.addWidget(self.lineEidt_video_path, 7, 2, 2, 1)

        self.label_video_name = QLabel(self.layoutWidget1)
        self.label_video_name.setObjectName(u"label_video_name")
        sizePolicy.setHeightForWidth(self.label_video_name.sizePolicy().hasHeightForWidth())
        self.label_video_name.setSizePolicy(sizePolicy)
        self.label_video_name.setMinimumSize(QSize(0, 0))

        self.gridLayout_5.addWidget(self.label_video_name, 6, 0, 1, 2)

        self.lineEdit_num_text = QLineEdit(self.layoutWidget1)
        self.lineEdit_num_text.setObjectName(u"lineEdit_num_text")
        sizePolicy.setHeightForWidth(self.lineEdit_num_text.sizePolicy().hasHeightForWidth())
        self.lineEdit_num_text.setSizePolicy(sizePolicy)
        self.lineEdit_num_text.setMinimumSize(QSize(50, 30))

        self.gridLayout_5.addWidget(self.lineEdit_num_text, 1, 2, 1, 1)

        self.label_img_path = QLabel(self.layoutWidget1)
        self.label_img_path.setObjectName(u"label_img_path")
        sizePolicy.setHeightForWidth(self.label_img_path.sizePolicy().hasHeightForWidth())
        self.label_img_path.setSizePolicy(sizePolicy)
        self.label_img_path.setMinimumSize(QSize(0, 0))

        self.gridLayout_5.addWidget(self.label_img_path, 5, 0, 1, 2)

        self.lineEdit_img_name = QLineEdit(self.layoutWidget1)
        self.lineEdit_img_name.setObjectName(u"lineEdit_img_name")
        sizePolicy.setHeightForWidth(self.lineEdit_img_name.sizePolicy().hasHeightForWidth())
        self.lineEdit_img_name.setSizePolicy(sizePolicy)
        self.lineEdit_img_name.setMinimumSize(QSize(50, 30))

        self.gridLayout_5.addWidget(self.lineEdit_img_name, 4, 2, 1, 1)

        self.lineEidt_video_name = QLineEdit(self.layoutWidget1)
        self.lineEidt_video_name.setObjectName(u"lineEidt_video_name")
        sizePolicy.setHeightForWidth(self.lineEidt_video_name.sizePolicy().hasHeightForWidth())
        self.lineEidt_video_name.setSizePolicy(sizePolicy)
        self.lineEidt_video_name.setMinimumSize(QSize(50, 30))

        self.gridLayout_5.addWidget(self.lineEidt_video_name, 6, 2, 1, 1)

        self.lineEdit_img_path = QLineEdit(self.layoutWidget1)
        self.lineEdit_img_path.setObjectName(u"lineEdit_img_path")
        sizePolicy.setHeightForWidth(self.lineEdit_img_path.sizePolicy().hasHeightForWidth())
        self.lineEdit_img_path.setSizePolicy(sizePolicy)
        self.lineEdit_img_path.setMinimumSize(QSize(50, 30))

        self.gridLayout_5.addWidget(self.lineEdit_img_path, 5, 2, 1, 1)

        self.label_video_path = QLabel(self.layoutWidget1)
        self.label_video_path.setObjectName(u"label_video_path")
        sizePolicy.setHeightForWidth(self.label_video_path.sizePolicy().hasHeightForWidth())
        self.label_video_path.setSizePolicy(sizePolicy)
        self.label_video_path.setMinimumSize(QSize(0, 0))

        self.gridLayout_5.addWidget(self.label_video_path, 7, 0, 2, 2)

        self.label_num_text = QLabel(self.layoutWidget1)
        self.label_num_text.setObjectName(u"label_num_text")
        sizePolicy.setHeightForWidth(self.label_num_text.sizePolicy().hasHeightForWidth())
        self.label_num_text.setSizePolicy(sizePolicy)
        self.label_num_text.setMinimumSize(QSize(0, 30))

        self.gridLayout_5.addWidget(self.label_num_text, 1, 0, 1, 2)

        self.label_ffmpeg = QLabel(self.layoutWidget1)
        self.label_ffmpeg.setObjectName(u"label_ffmpeg")
        self.label_ffmpeg.setMinimumSize(QSize(0, 20))
        self.label_ffmpeg.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.gridLayout_5.addWidget(self.label_ffmpeg, 0, 0, 1, 3)

        self.label_video_format = QLabel(self.layoutWidget1)
        self.label_video_format.setObjectName(u"label_video_format")
        sizePolicy.setHeightForWidth(self.label_video_format.sizePolicy().hasHeightForWidth())
        self.label_video_format.setSizePolicy(sizePolicy)
        self.label_video_format.setMinimumSize(QSize(0, 30))

        self.gridLayout_5.addWidget(self.label_video_format, 3, 0, 1, 2)

        self.label_img_format = QLabel(self.layoutWidget1)
        self.label_img_format.setObjectName(u"label_img_format")
        sizePolicy.setHeightForWidth(self.label_img_format.sizePolicy().hasHeightForWidth())
        self.label_img_format.setSizePolicy(sizePolicy)
        self.label_img_format.setMinimumSize(QSize(0, 30))

        self.gridLayout_5.addWidget(self.label_img_format, 2, 0, 1, 2)

        self.lineEdit_img_format = QLineEdit(self.layoutWidget1)
        self.lineEdit_img_format.setObjectName(u"lineEdit_img_format")
        sizePolicy.setHeightForWidth(self.lineEdit_img_format.sizePolicy().hasHeightForWidth())
        self.lineEdit_img_format.setSizePolicy(sizePolicy)
        self.lineEdit_img_format.setMinimumSize(QSize(50, 30))

        self.gridLayout_5.addWidget(self.lineEdit_img_format, 2, 2, 1, 1)

        self.lineEdit_video_format = QLineEdit(self.layoutWidget1)
        self.lineEdit_video_format.setObjectName(u"lineEdit_video_format")
        sizePolicy.setHeightForWidth(self.lineEdit_video_format.sizePolicy().hasHeightForWidth())
        self.lineEdit_video_format.setSizePolicy(sizePolicy)
        self.lineEdit_video_format.setMinimumSize(QSize(50, 30))

        self.gridLayout_5.addWidget(self.lineEdit_video_format, 3, 2, 1, 1)

        self.layoutWidget_5 = QWidget(self.centralwidget)
        self.layoutWidget_5.setObjectName(u"layoutWidget_5")
        self.layoutWidget_5.setGeometry(QRect(507, 604, 601, 102))
        self.horizontalLayout_11 = QHBoxLayout(self.layoutWidget_5)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.horizontalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.pushButton_save = QPushButton(self.layoutWidget_5)
        self.pushButton_save.setObjectName(u"pushButton_save")
        sizePolicy.setHeightForWidth(self.pushButton_save.sizePolicy().hasHeightForWidth())
        self.pushButton_save.setSizePolicy(sizePolicy)
        self.pushButton_save.setMinimumSize(QSize(100, 100))

        self.horizontalLayout_11.addWidget(self.pushButton_save)

        self.pushButton_render = QPushButton(self.layoutWidget_5)
        self.pushButton_render.setObjectName(u"pushButton_render")
        sizePolicy.setHeightForWidth(self.pushButton_render.sizePolicy().hasHeightForWidth())
        self.pushButton_render.setSizePolicy(sizePolicy)
        self.pushButton_render.setMinimumSize(QSize(100, 100))

        self.horizontalLayout_11.addWidget(self.pushButton_render)

        self.pushButton_create_vid = QPushButton(self.layoutWidget_5)
        self.pushButton_create_vid.setObjectName(u"pushButton_create_vid")
        sizePolicy.setHeightForWidth(self.pushButton_create_vid.sizePolicy().hasHeightForWidth())
        self.pushButton_create_vid.setSizePolicy(sizePolicy)
        self.pushButton_create_vid.setMinimumSize(QSize(100, 100))

        self.horizontalLayout_11.addWidget(self.pushButton_create_vid)

        self.layoutWidget_6 = QWidget(self.centralwidget)
        self.layoutWidget_6.setObjectName(u"layoutWidget_6")
        self.layoutWidget_6.setGeometry(QRect(510, 40, 601, 71))
        self.horizontalLayout_12 = QHBoxLayout(self.layoutWidget_6)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.horizontalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.groupBox_4 = QGroupBox(self.layoutWidget_6)
        self.groupBox_4.setObjectName(u"groupBox_4")
        sizePolicy2.setHeightForWidth(self.groupBox_4.sizePolicy().hasHeightForWidth())
        self.groupBox_4.setSizePolicy(sizePolicy2)
        self.layoutWidget_7 = QWidget(self.groupBox_4)
        self.layoutWidget_7.setObjectName(u"layoutWidget_7")
        self.layoutWidget_7.setGeometry(QRect(10, 10, 491, 51))
        self.gridLayout_17 = QGridLayout(self.layoutWidget_7)
        self.gridLayout_17.setObjectName(u"gridLayout_17")
        self.gridLayout_17.setContentsMargins(0, 0, 0, 0)
        self.label_mesh_name = QLabel(self.layoutWidget_7)
        self.label_mesh_name.setObjectName(u"label_mesh_name")
        sizePolicy.setHeightForWidth(self.label_mesh_name.sizePolicy().hasHeightForWidth())
        self.label_mesh_name.setSizePolicy(sizePolicy)
        self.label_mesh_name.setMinimumSize(QSize(0, 0))

        self.gridLayout_17.addWidget(self.label_mesh_name, 0, 0, 1, 1)

        self.label_selected_mesh_name = QLabel(self.layoutWidget_7)
        self.label_selected_mesh_name.setObjectName(u"label_selected_mesh_name")
        sizePolicy2.setHeightForWidth(self.label_selected_mesh_name.sizePolicy().hasHeightForWidth())
        self.label_selected_mesh_name.setSizePolicy(sizePolicy2)
        self.label_selected_mesh_name.setMinimumSize(QSize(0, 0))

        self.gridLayout_17.addWidget(self.label_selected_mesh_name, 0, 1, 1, 1)

        self.label_camera_name = QLabel(self.layoutWidget_7)
        self.label_camera_name.setObjectName(u"label_camera_name")
        sizePolicy.setHeightForWidth(self.label_camera_name.sizePolicy().hasHeightForWidth())
        self.label_camera_name.setSizePolicy(sizePolicy)
        self.label_camera_name.setMinimumSize(QSize(0, 0))

        self.gridLayout_17.addWidget(self.label_camera_name, 1, 0, 1, 1)

        self.label_selected_camera_name = QLabel(self.layoutWidget_7)
        self.label_selected_camera_name.setObjectName(u"label_selected_camera_name")
        sizePolicy2.setHeightForWidth(self.label_selected_camera_name.sizePolicy().hasHeightForWidth())
        self.label_selected_camera_name.setSizePolicy(sizePolicy2)
        self.label_selected_camera_name.setMinimumSize(QSize(0, 0))

        self.gridLayout_17.addWidget(self.label_selected_camera_name, 1, 1, 1, 1)


        self.horizontalLayout_12.addWidget(self.groupBox_4)

        self.pushButton_import = QPushButton(self.layoutWidget_6)
        self.pushButton_import.setObjectName(u"pushButton_import")
        sizePolicy.setHeightForWidth(self.pushButton_import.sizePolicy().hasHeightForWidth())
        self.pushButton_import.setSizePolicy(sizePolicy)
        self.pushButton_import.setMinimumSize(QSize(0, 0))

        self.horizontalLayout_12.addWidget(self.pushButton_import)

        self.pushButton_save_file_path = QPushButton(self.centralwidget)
        self.pushButton_save_file_path.setObjectName(u"pushButton_save_file_path")
        self.pushButton_save_file_path.setGeometry(QRect(1027, 564, 80, 28))
        sizePolicy.setHeightForWidth(self.pushButton_save_file_path.sizePolicy().hasHeightForWidth())
        self.pushButton_save_file_path.setSizePolicy(sizePolicy)
        self.pushButton_save_file_path.setMinimumSize(QSize(0, 0))
        self.label_scene_name = QLabel(self.centralwidget)
        self.label_scene_name.setObjectName(u"label_scene_name")
        self.label_scene_name.setGeometry(QRect(508, 530, 91, 28))
        sizePolicy.setHeightForWidth(self.label_scene_name.sizePolicy().hasHeightForWidth())
        self.label_scene_name.setSizePolicy(sizePolicy)
        self.label_scene_name.setMinimumSize(QSize(0, 0))
        self.lineEdit_scene_path = QLineEdit(self.centralwidget)
        self.lineEdit_scene_path.setObjectName(u"lineEdit_scene_path")
        self.lineEdit_scene_path.setGeometry(QRect(597, 564, 421, 28))
        sizePolicy5 = QSizePolicy(QSizePolicy.MinimumExpanding, QSizePolicy.Preferred)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.lineEdit_scene_path.sizePolicy().hasHeightForWidth())
        self.lineEdit_scene_path.setSizePolicy(sizePolicy5)
        self.lineEdit_scene_path.setMinimumSize(QSize(0, 0))
        self.label_scene_path = QLabel(self.centralwidget)
        self.label_scene_path.setObjectName(u"label_scene_path")
        self.label_scene_path.setGeometry(QRect(508, 564, 83, 28))
        sizePolicy.setHeightForWidth(self.label_scene_path.sizePolicy().hasHeightForWidth())
        self.label_scene_path.setSizePolicy(sizePolicy)
        self.label_scene_path.setMinimumSize(QSize(0, 0))
        self.lineEdit_scene_name = QLineEdit(self.centralwidget)
        self.lineEdit_scene_name.setObjectName(u"lineEdit_scene_name")
        self.lineEdit_scene_name.setGeometry(QRect(597, 530, 511, 28))
        sizePolicy5.setHeightForWidth(self.lineEdit_scene_name.sizePolicy().hasHeightForWidth())
        self.lineEdit_scene_name.setSizePolicy(sizePolicy5)
        self.lineEdit_scene_name.setMinimumSize(QSize(0, 0))
        self.lineEdit_scene_format = QLineEdit(self.centralwidget)
        self.lineEdit_scene_format.setObjectName(u"lineEdit_scene_format")
        self.lineEdit_scene_format.setGeometry(QRect(637, 490, 118, 30))
        sizePolicy.setHeightForWidth(self.lineEdit_scene_format.sizePolicy().hasHeightForWidth())
        self.lineEdit_scene_format.setSizePolicy(sizePolicy)
        self.lineEdit_scene_format.setMinimumSize(QSize(50, 30))
        self.label_scene_format = QLabel(self.centralwidget)
        self.label_scene_format.setObjectName(u"label_scene_format")
        self.label_scene_format.setGeometry(QRect(510, 490, 111, 30))
        sizePolicy.setHeightForWidth(self.label_scene_format.sizePolicy().hasHeightForWidth())
        self.label_scene_format.setSizePolicy(sizePolicy)
        self.label_scene_format.setMinimumSize(QSize(0, 30))
        self.label_scene_save = QLabel(self.centralwidget)
        self.label_scene_save.setObjectName(u"label_scene_save")
        self.label_scene_save.setGeometry(QRect(507, 460, 531, 20))
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(2)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label_change_hdri_img.setText(QCoreApplication.translate("MainWindow", u"Change Background HDRI Image:", None))
        self.label_preview_hdri_img.setText(QCoreApplication.translate("MainWindow", u"Preview of imported HDRI image...", None))
        self.pushButton_add_hdri_img.setText(QCoreApplication.translate("MainWindow", u"Add HDRI Image", None))
        self.label_hdri_path.setText(QCoreApplication.translate("MainWindow", u"File path: ", None))
        self.pushButton_hdri_path.setText(QCoreApplication.translate("MainWindow", u"Open", None))
        self.label_add_hdri_img.setText(QCoreApplication.translate("MainWindow", u"Add HDI Image:", None))
        self.label_hdri_project.setText(QCoreApplication.translate("MainWindow", u"Project:", None))
        self.label_hdri_asset.setText(QCoreApplication.translate("MainWindow", u"Asset:", None))
        self.label_hdri_task.setText(QCoreApplication.translate("MainWindow", u"Task:", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_1_hdri), QCoreApplication.translate("MainWindow", u"HDRI", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2_render), QCoreApplication.translate("MainWindow", u"Render", None))
        self.label_selected_vid_name.setText(QCoreApplication.translate("MainWindow", u"'selected_Vid(rendered result)'", None))
        self.label_user.setText(QCoreApplication.translate("MainWindow", u"User:", None))
        self.label_video.setText(QCoreApplication.translate("MainWindow", u"Video:", None))
        self.label_user_name.setText(QCoreApplication.translate("MainWindow", u"'logged_in_user_name'", None))
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"PushButton", None))
        self.label_preview_vid.setText(QCoreApplication.translate("MainWindow", u"Preview of rendered video", None))
        self.label_vid_project.setText(QCoreApplication.translate("MainWindow", u"Project:", None))
        self.label_vid_task.setText(QCoreApplication.translate("MainWindow", u"Task:", None))
        self.label_vid_asset.setText(QCoreApplication.translate("MainWindow", u"Asset:", None))
        self.label_post_comment.setText(QCoreApplication.translate("MainWindow", u"Post Comment:", None))
        self.textEdit_leave_a_comment.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Cantarell'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Leave a comment...</p></body></html>", None))
        self.pushButton_publish.setText(QCoreApplication.translate("MainWindow", u"Publish", None))
        self.pushButton_go_kitsu.setText(QCoreApplication.translate("MainWindow", u"Go Kitsu", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_3_kitsu), QCoreApplication.translate("MainWindow", u"Kitsu", None))
        self.label_asset_lib.setText(QCoreApplication.translate("MainWindow", u"Asset Library:", None))
        self.label_add_asset_img.setText(QCoreApplication.translate("MainWindow", u"Add Asset Image:", None))
        self.label_asset_path.setText(QCoreApplication.translate("MainWindow", u"File path: ", None))
        self.pushButton_asset_path.setText(QCoreApplication.translate("MainWindow", u"Open", None))
        self.label_asset_lib_project.setText(QCoreApplication.translate("MainWindow", u"Project:", None))
        self.label_asset_lib_asset.setText(QCoreApplication.translate("MainWindow", u"Asset:", None))
        self.label_asset_lib_task.setText(QCoreApplication.translate("MainWindow", u"Task:", None))
        self.pushButton_add_asset.setText(QCoreApplication.translate("MainWindow", u"Add Asset", None))
        self.pushButton_import_asset.setText(QCoreApplication.translate("MainWindow", u"Import Asset", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_4_asset_lib), QCoreApplication.translate("MainWindow", u"Asset LIb", None))
        self.groupBox_3.setTitle("")
        self.label_mesh.setText(QCoreApplication.translate("MainWindow", u"[ Mesh ]", None))
        self.label_skydome.setText(QCoreApplication.translate("MainWindow", u"[ Skydome ]", None))
        self.label_mesh_start_frame.setText(QCoreApplication.translate("MainWindow", u"Start Frame:", None))
        self.label_skydome_start_frame.setText(QCoreApplication.translate("MainWindow", u"Start Frame:", None))
        self.label_mesh_end_frame.setText(QCoreApplication.translate("MainWindow", u"End Frame:", None))
        self.label_skydome_end_frame.setText(QCoreApplication.translate("MainWindow", u"End Frame:", None))
        self.label_mesh_start_rotate.setText(QCoreApplication.translate("MainWindow", u"Start Rotate:", None))
        self.lineEdit_mesh_start_rotate.setText(QCoreApplication.translate("MainWindow", u"\u00b0", None))
        self.label_skydome_start_rotate.setText(QCoreApplication.translate("MainWindow", u"Start Rotate:", None))
        self.lineEdit_skydome_start_rotate.setText(QCoreApplication.translate("MainWindow", u"\u00b0", None))
        self.label_mesh_end_rotate.setText(QCoreApplication.translate("MainWindow", u"End Rotate:", None))
        self.lineEdit_mesh_end_rotate.setText(QCoreApplication.translate("MainWindow", u"\u00b0", None))
        self.label_skydome_end_rotate.setText(QCoreApplication.translate("MainWindow", u"End Rotate:", None))
        self.lineEdit_skydome_end_rotate.setText(QCoreApplication.translate("MainWindow", u"\u00b0", None))
        self.pushButton_hypershade.setText(QCoreApplication.translate("MainWindow", u"Hypershade", None))
        self.pushButton_render_setting.setText(QCoreApplication.translate("MainWindow", u"Render Setting", None))
        self.pushButton_render_view.setText(QCoreApplication.translate("MainWindow", u"Render View", None))
        self.label_img_name.setText(QCoreApplication.translate("MainWindow", u"Image Name:", None))
        self.lineEidt_video_path.setText(QCoreApplication.translate("MainWindow", u"04", None))
        self.lineEidt_video_path.setPlaceholderText("")
        self.label_video_name.setText(QCoreApplication.translate("MainWindow", u"Video Name:", None))
        self.lineEdit_num_text.setText(QCoreApplication.translate("MainWindow", u"04", None))
        self.lineEdit_num_text.setPlaceholderText("")
        self.label_img_path.setText(QCoreApplication.translate("MainWindow", u"Image Path: ", None))
        self.lineEdit_img_name.setText("")
        self.lineEdit_img_name.setPlaceholderText("")
        self.lineEidt_video_name.setText(QCoreApplication.translate("MainWindow", u"test_vid", None))
        self.lineEidt_video_name.setPlaceholderText("")
        self.lineEdit_img_path.setText("")
        self.lineEdit_img_path.setPlaceholderText("")
        self.label_video_path.setText(QCoreApplication.translate("MainWindow", u"Video Path: ", None))
        self.label_num_text.setText(QCoreApplication.translate("MainWindow", u"Num Text:", None))
        self.label_ffmpeg.setText(QCoreApplication.translate("MainWindow", u"[ ffmpeg ]", None))
        self.label_video_format.setText(QCoreApplication.translate("MainWindow", u"Video Format:", None))
        self.label_img_format.setText(QCoreApplication.translate("MainWindow", u"Image Format:", None))
        self.lineEdit_img_format.setText(QCoreApplication.translate("MainWindow", u"mb", None))
        self.lineEdit_video_format.setText(QCoreApplication.translate("MainWindow", u"04", None))
        self.lineEdit_video_format.setPlaceholderText("")
        self.pushButton_save.setText(QCoreApplication.translate("MainWindow", u"Save", None))
        self.pushButton_render.setText(QCoreApplication.translate("MainWindow", u"Render", None))
        self.pushButton_create_vid.setText(QCoreApplication.translate("MainWindow", u"Create Video", None))
        self.groupBox_4.setTitle("")
        self.label_mesh_name.setText(QCoreApplication.translate("MainWindow", u"Name:", None))
        self.label_selected_mesh_name.setText(QCoreApplication.translate("MainWindow", u"'selected_mesh_name'", None))
        self.label_camera_name.setText(QCoreApplication.translate("MainWindow", u"Camera:", None))
        self.label_selected_camera_name.setText(QCoreApplication.translate("MainWindow", u"'selected_camera_name'", None))
        self.pushButton_import.setText(QCoreApplication.translate("MainWindow", u"Import", None))
        self.pushButton_save_file_path.setText(QCoreApplication.translate("MainWindow", u"Save", None))
        self.label_scene_name.setText(QCoreApplication.translate("MainWindow", u"Scene Name:", None))
        self.label_scene_path.setText(QCoreApplication.translate("MainWindow", u"Scene Path: ", None))
        self.lineEdit_scene_format.setText(QCoreApplication.translate("MainWindow", u"mb", None))
        self.label_scene_format.setText(QCoreApplication.translate("MainWindow", u"Scene Format:", None))
        self.label_scene_save.setText(QCoreApplication.translate("MainWindow", u"[ Scene File Save ]", None))
    # retranslateUi
