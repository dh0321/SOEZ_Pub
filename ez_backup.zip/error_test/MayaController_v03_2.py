# -*- coding: utf-8 -*-

from PySide2.QtWidgets import QMainWindow
from pymel.core import *
from maya import mel
import sys
import math
import os
import maya.cmds as cmds
import importlib

sys.path.insert(0, "/home/rapa/MayaProjects/importsettings1/scripts")

import scaled_in_grid_ver2_5
import import_and_setting_0727

reload(scaled_in_grid_ver2_5)
reload(import_and_setting_0727)

from scaled_in_grid_ver2_5 import Ui_MainWindow as ezui
from import_and_setting_0727 import part2 as iands

iands = iands()

class MainWindow(QMainWindow, ezui):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)

        # button tests
        self.pushButton_render_view.clicked.connect(self.render_view_clicked)
        self.pushButton_render_setting.clicked.connect(self.render_setting_clicked)
        self.pushButton_hypershade.clicked.connect(self.hypershade_clicked)
        self.pushButton_render.clicked.connect(self.render_clicked)
        self.pushButton_create_vid.clicked.connect(self.create_vid_clicked)
        self.pushButton_save_file_path.clicked.connect(self.save_clicked)
        if cmds.ls(selection=True):
            self.label_selected_mesh_name.setText(cmds.ls(selection=True)[0])
        else:
            pass

        self.pushButton_go_kitsu.clicked.connect(self.rotate_test)


    def render_view_clicked(self):
        cmds.setAttr('defaultResolution.deviceAspectRatio')
        mel.eval('RenderViewWindow')
        mel.eval('renderWindowRenderCamera iprRender renderView turntable_cameraShape;')

    def render_setting_clicked(self):
        mel.eval('unifiedRenderGlobalsWindow;')

    def hypershade_clicked(self):
        mel.eval('HypershadeWindow;')

    def render_clicked(self):
        s = 1  # start frame 렌더 시작 프레임 설정
        e = 24  # end frame 렌더 끝내는 프레임 설정
        nframes = e - s + 1
        amount = 0
        counter = 0
        start_frame = s
        for i in range(start_frame, e + 1):
            currentTime(i)
            if i < s:
                continue
            mel.eval('renderWindowRender redoPreviousRender renderView;')
            counter += 1
            amount = int(math.floor(counter / nframes))

        print('# Done')

    def create_vid_clicked(self):
        input_directory = '/home/rapa/maya/projects/default/images/tmp'
        image_sequence_name = 'test_cog_v01_1'
        num_text = '%04d'
        file_extension = 'exr'
        output_directory = '/home/rapa/maya_test/cog_asset_v01/ren_mov'
        output_name = 'cog_v01'
        output_vide_format = 'mov'

        command_input = 'ffmpeg -i %s/%s.%s.%s %s/%s.%s' % (
            input_directory, image_sequence_name, num_text, file_extension, output_directory, output_name,
            output_vide_format)

        if os.system(command_input) == 0:
            mel.eval('confirmDialog -title "Confirm" -message "Convert Finished Successfully"')
        else:
            print('confirmDialog -title "Confirm" -message "There was an error running your ffmpeg script"')


    def save_clicked(self):
        path = self.lineEdit_save_file_path.text()
        name = self.lineEdit_render_file_name.text()
        representation = 'mb'
        full_path = path + name + '.' + representation
        maya_path = os.path.dirname(full_path)
        if not os.path.exists(maya_path):
            os.makedirs(maya_path)
        cmds.file(rename=full_path)
        if representation == 'mb':
            cmds.file(save=True, type='mayaBinary', force=True)
        else:
            cmds.file(save=True, type='mayaAscii', force=True)


    def rotate_test(self):
        print("go kitsu button is clicked")

        m1 = int(self.lineEdit_mesh_start_frame.text())
        m2 = int(self.lineEdit_mesh_end_frame.text())
        m3 = int(self.lineEdit_mesh_start_rotate.text())
        m4 = int(self.lineEdit_mesh_end_rotate.text())

        a = int(self.lineEdit_skydome_start_frame.text())
        b = int(self.lineEdit_mesh_end_frame.text())
        s1 = int(self.lineEdit_skydome_start_rotate.text())
        s2 = int(self.lineEdit_skydome_end_rotate.text())
        s3 = m1 + a
        s4 = m1 + b

        iands.rotate_objects(m3, m4, m1, m2)
        iands.rotate_dome(s3, s4, s1, s2)




if __name__ == "__main__":

    try:
        MainWindow.close()
        MainWindow.deleteLater()
    except:
        pass

    td = MainWindow()
    td.show()
