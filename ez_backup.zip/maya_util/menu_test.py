# -*- coding: utf-8 -*-

import maya.cmds as cmds
import sys

sys.path.append('/home/rapa/PycharmProjects/team_soez/tmp')

if cmds.menu('EZMenu', exists=True):
    cmds.menu('EZMenu', e=True, dai=True)
else:
    cmds.setParent('MayaWindow')
    cmds.menu('EZMenu', l="EZPUB", p='MayaWindow', to=True)

cmds.setParent(menu=True)

cmds.menuItem(l="EZPUB", sm=True, to=True)
cmds.menuItem(l="EZPUB_API", c="from MayaController_v03_6_2 import MainWindow; td = MainWindow(); td.show();",
            ann="Open the EZPUB.", image="/home/rapa/다운로드/beer-mug-clipart-2.png")
cmds.setParent(menu=True)

shelf_name = "EZPUB"
cmds.shelfLayout(shelf_name, p="ShelfLayout")
cmds.shelfButton(
    label="EZPUB_API",
    image="/home/rapa/다운로드/beer-mug-clipart-2.png",
    command="from MayaController_v03_6_2import MainWindow; td = MainWindow(); td.show();",
    parent=shelf_name
)
