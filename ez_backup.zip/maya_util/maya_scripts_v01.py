'''
open hypershade
mel 스크립트를 python 에서 사용하려면 아래와 같이 mel.eval(mel 명령어) 식으로 써줘야함
'''

from maya import mel

mel.eval('HypershadeWindow;')


'''
mel 스크립트로 메시지 박스 띄우는 예시
'''
import maya.mel as mel

mel.eval('confirmDialog -title "Confirm" -message "Are you sure?" -button "OK" -button "Cancel" -defaultButton "OK" -cancelButton "Cancel" -dismissString "Cancel";')

'''
mel 스크립트로 내부 경로 띄우는 스크립트 예시
'''
import maya.mel as mel

mel.eval('fileDialog -directoryMask "*.txt"')


'''
render view 창을 띄워주는 스크립트
'''

import maya.cmds as cmds
import maya.mel as mel

cmds.setAttr('defaultResolution.deviceAspectRatio')
mel.eval('RenderViewWindow')

'''
프로젝트 윈도우창 띄워주는 스크립트
'''

import maya.mel

mel.eval('ProjectWindow;')

'''
렌더세팅 창 띄워주는 스크립트
'''

import maya.mel

mel.eval('unifiedRenderGlobalsWindow;')

'''
씬파일 저장해주는 스크립트
'''

import maya.cmds as cmds
import os

def save_scene_file(path, representation):
    full_path = path+'.'+representation
    maya_path = os.path.dirname(full_path)
    if os.path.exists(maya_path) == False:          
         os.makedirs(maya_path)
    cmds.file(rename=full_path)         
    if representation == 'mb':
        cmds.file(save=True, type='mayaBinary', force=True)
    else:       
        cmds.file(save=True, type='mayaAscii', force=True)
        
save_scene_file('/home/rapa/maya/projects/default/images/tmp', 'ma')


###################################################
# path 파라미터에 들어가는 부분의 경우,
# /home/rapa/maya/projects/default/images/ => 경로
# tmp => 씬파일 이름으로 저장됨
###################################################


