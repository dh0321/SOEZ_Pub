from PySide2.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QGridLayout,
    QWidget, QLineEdit, QPushButton, QLabel, QDialog, QFileDialog, QMessageBox, QScrollArea, QGraphicsScene)
from PySide2.QtCore import Qt, QSettings, QSize
from PySide2.QtGui import QGuiApplication, QScreen, QIcon, QKeySequence, QMovie, QPixmap, QImage
import os.path

# import maya.cmds as cmds
# import maya.mel as mel
import webbrowser
print(webbrowser)
import pickle
from login_ui_ver2_6 import Ui_MainWindow



class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.setupUi(self)

        self.pushButton_login.clicked.connect(self.login_clicked)
        self.checkBox_autologin.stateChanged.connect(self.check_box_changed)
        self.commandLinkButton_find_pw.clicked.connect(self.go_finding_password_web) # executed()

        # set label FixedSize
        # self.label_title_kitsu.setFixedSize(80, 30)

        # original img
        original_image = QImage("kitsu.png")
        original_image2 = QImage("soez_title.png")

        # rescaled jpg/png
        # original_image2.scaled(16, 9)
        # original_image2.save("new_image.png")
        pixmap = QPixmap(os.path.join(os.path.dirname(__file__), "kitsu.png"))
        pixmap2 = QPixmap(os.path.join(os.path.dirname(__file__), "new_image.png"))
        self.label_title_kitsu.setPixmap(pixmap)
        # self.label_title_l.setPixmap(pixmap2)
        # self.label_title_r.setPixmap(pixmap2)

    def check_box_changed(self):
        checked = self.checkBox_autologin.isChecked()
        print("The state of the checkbox is", checked)
        if checked == True:
            print("autologin")
        elif checked == False:
            print("pass autologin")
        else:
            print("error")


    def login_clicked(self):
        print('login_kitsu')

        # check auto login
        self.check_box_changed()

        # kitsu login
        self.kitsu_login()
        return True

    def kitsu_login(self):
        # kitsu login pass....
        # input_user_email = gazu.setuseremail??(self.lineEdit_useremail)
        # input_user_pw = gazu.setuserpw??(self.lineEdit_userpw)

        # set username
        self.logged_in_user_name()
        print ('kitsu_login_success')

    def autologin_checked(self):
        print('autologin_checked')

    def go_finding_password_web(self):
        find_user_account = "http://192.168.3.117/reset-password"
        webbrowser.open(find_user_account)
        print('go_finding_password_web')

    def logged_in_user_name(self):
        # return self.gazu.username??
        print ('logged_in_user_name')


app = QApplication()

window = MainWindow()
window.show()

app.exec_()