import sys
sys.path.insert(0, "/home/rapa/maya/scripts")
from login_controller import LoginWindow
from login_model import LogIn

from MayaController_v03_7 import MainWindow




class EZPUB:
    def __init__(self):
        self.login = LogIn()
        self.lg = LoginWindow()
        self.mainwindow = MainWindow()

        self.user_dict = self.login.load_login_info()

    def auto(self):
        if self.user_dict["valid_user"] is True and self.user_dict["auto_login"] is True:
            self.main()
        else:
            self.log_in_window()

    def main(self):
        self.mainwindow.show()

    def log_in_window(self):
        self.lg.show()
        # if self.lg.login.log_in:
        #     self.main()
        # if self.user_dict["valid_user"]:
        #     self.main()


#
# if __name__ == "__main__":
#
#     if user_dict["valid_user"] and user_dict["auto_login"]:
#         td = MainWindow()
#         td.show()
#     else:
#         lg = LoginWindow()
#         lg.show()
#         if lg.close:
#             td = MainWindow()
#             td.show()
#     try:
#         LoginWindow.close()
#         LoginWindow.deleteLater()
#     except:
#         pass
#
#     LG = LoginWindow()
#     LG.show()
