# coding=utf-8
import sys
from PySide2.QtWidgets import QApplication, QMainWindow, QLineEdit
from PySide2.QtGui import QImage, QPixmap

import webbrowser

sys.path.insert(0, "/home/rapa/maya/scripts")

from login_ui_ver2_6 import Ui_MainWindow
from login_model import LogIn
from logger import Logger

from MayaController_v03_7 import MainWindow


class LoginWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(LoginWindow, self).__init__()

    # UI
        self.setupUi(self)
        self.setWindowTitle("KITSU LOGIN")
        self.label_login_error.setText("")
        self.lineEdit_login_pw.setEchoMode(QLineEdit.Password)
        self.img_kitsu = QImage('/home/rapa/maya/scripts/kitsu.png')
        # self.img_kitsu = QPixmap.fromImage(self.img_kitsu)
        self.label_title_kitsu.setPixmap(QPixmap.fromImage(self.img_kitsu))

        self.label_title_l.clear()
        self.label_title_r.clear()

    # module
        self.log = Logger()
        self.login = LogIn()
        self.mainwindow = MainWindow()

    # signal & slot
        self.pushButton_login.clicked.connect(self.pushButton_login_clicked)
        self.lineEdit_login_email.returnPressed.connect(self.pushButton_login_clicked)
        self.lineEdit_login_pw.returnPressed.connect(self.pushButton_login_clicked)
        self.commandLinkButton_find_pw.clicked.connect(self.find_pw_clicked)

    def pushButton_login_clicked(self):

        self.login.host = 'http://192.168.3.117/api'
        self.login.connect_host()

        self.login.user_id = self.lineEdit_login_email.text()
        self.login.user_pw = self.lineEdit_login_pw.text()
        self.login.auto_login_setting = self.checkBox_autologin.isChecked()

        self.login.log_in()
        if self.login.valid_user is True:
            print("성공")
            if self.login.auto_login_setting == True:
                self.login.save_login_info()
                print('자동로그인 정보저장')
            self.window().close()
            self.mainwindow.show()
        else:
            self.set_text_errormassage()
            self.lineEdit_login_pw.clear()

        return self.login.host, self.login.user_id, self.login.user_pw

    def set_text_errormassage(self):
        self.label_login_error.setText(self.login.errormassage)
        print("Login label changed!")

    def find_pw_clicked(self):
        forgot_password_browser = 'http://192.168.3.117/reset-password'
        webbrowser.open(forgot_password_browser)


if __name__ == "__main__":
    # maya test
        try:
            LoginWindow.close()
            LoginWindow.deleteLater()
        except:
            pass

        td = LoginWindow()
        td.show()

        if td.close():
            a = MayaController_v03_4.MainWindow()
            a.show()

# test
