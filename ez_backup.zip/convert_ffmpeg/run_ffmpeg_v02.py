import os

# 아래 class 변수들은 ffmpeg 커맨드를 실행하는데 control 이 필요한 부분들을 나눈 class 변수들이다.
# 쉽게 얘기하면 아래 변수들은 user input 이 필요한 부분이다.
input_directory = '/home/rapa/maya_test/ren_test'
image_sequence_name = 'box'
num_text = '%04d'
file_extension = 'exr'
output_directory = '/home/rapa/maya_test'
output_name = 'box'
output_vide_format = 'mov'

# 아래 class 변수는 위의 class 변수들을 종합하여 터미널에 input 될 커맨드를 새 class 변수로 생성한다.
command_input = 'ffmpeg -i %s/%s.%s.%s %s/%s.%s' % (input_directory, image_sequence_name, num_text, file_extension, output_directory, output_name, output_vide_format)
print(command_input)

# 아래 메소드는 command_input 이라는 class 변수를 commands 매개변수에 input 하여 ffmpeg 가 터미널에서 실행되게끔 해준다.


def runffmpeg(commands):
    if os.system(commands) == 0:
        print("ffmpeg Script Ran Successfully")
    else:
        print("There was an error running your ffmpeg script")

# 아래 코멘트 처리된 print 코드는 ffmpeg 를 실행하는 터미널 커맨드를 확인하기 위한 것. 실질적 작동에는 불필요
# print(command_input)
# print(type(command_input))

# 아래 코드로 기능이 실행된다


# runffmpeg(command_input)
